'use strict';
const { app, BrowserWindow, ipcMain, dialog, shell, session, nativeImage, net, Menu } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn, execFile } = require('child_process');
const { pathToFileURL } = require('url');

app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

// ───────────────────────── Папка данных ─────────────────────────
// Портативная версия хранит всё рядом с exe (NovaData), установленная — в профиле пользователя.
const portableDir = process.env.PORTABLE_EXECUTABLE_DIR;
const DATA_DIR = portableDir ? path.join(portableDir, 'NovaData') : path.join(app.getPath('userData'), 'data');
const ASSETS_DIR = path.join(DATA_DIR, 'assets');
const DB_FILE = path.join(DATA_DIR, 'data.json');
fs.mkdirSync(ASSETS_DIR, { recursive: true });

const CHROME_UA = `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${process.versions.chrome} Safari/537.36`;

function defaultDB() {
  return {
    version: 1,
    settings: {
      userName: 'Игрок',
      fullscreen: true,
      autostart: true,
      uiSounds: true,
      music: true,
      volume: 60,
      musicHome: '', musicHomeName: '',
      musicGames: '', musicGamesName: '',
      musicApps: '', musicAppsName: '',
      musicSites: '', musicSitesName: '',
      bgHome: '',
      mediaFolder: '',
    },
    games: [],
    apps: [
      { id: 'app-media', name: 'Мультимедиа', kind: 'media', icon: '', glyph: 'film', color: '#7a3cff' },
      { id: 'app-browser', name: 'Браузер', kind: 'web', target: 'https://www.google.com', icon: '', glyph: 'globe', color: '#1f8bff' },
      { id: 'app-steam', name: 'Steam', kind: 'url', target: 'steam://open/main', icon: '', glyph: 'play', color: '#1b6a9c' },
      { id: 'app-explorer', name: 'Проводник', kind: 'cmd', target: 'explorer.exe', icon: '', glyph: 'folder', color: '#e2a42b' },
      { id: 'app-settings', name: 'Параметры Windows', kind: 'cmd', target: 'ms-settings:', icon: '', glyph: 'gear', color: '#5b6b83' },
      { id: 'app-taskmgr', name: 'Диспетчер задач', kind: 'cmd', target: 'taskmgr.exe', icon: '', glyph: 'activity', color: '#2a9d6f' },
    ],
    sites: [
      { id: 's-youtube', name: 'YouTube', url: 'https://www.youtube.com', color: '#d4312c', embedded: true, icon: '' },
      { id: 's-claude', name: 'Claude', url: 'https://claude.ai', color: '#cc7a55', embedded: true, icon: '' },
      { id: 's-github', name: 'GitHub', url: 'https://github.com', color: '#2b3137', embedded: true, icon: '' },
      { id: 's-twitch', name: 'Twitch', url: 'https://www.twitch.tv', color: '#6a3fb5', embedded: true, icon: '' },
      { id: 's-google', name: 'Google', url: 'https://www.google.com', color: '#3b78e7', embedded: true, icon: '' },
      { id: 's-telegram', name: 'Telegram', url: 'https://web.telegram.org', color: '#2698d4', embedded: true, icon: '' },
      { id: 's-wiki', name: 'Википедия', url: 'https://ru.wikipedia.org', color: '#4a4f57', embedded: true, icon: '' },
      { id: 's-kp', name: 'Кинопоиск', url: 'https://www.kinopoisk.ru', color: '#e8590c', embedded: true, icon: '' },
    ],
    achievements: {},
    stats: { days: [], maxSession: 0, night: false, sites: false },
  };
}

function loadDB() {
  const d = defaultDB();
  let db = null;
  try { db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch { /* первый запуск */ }
  if (!db) return d;
  db.settings = { ...d.settings, ...(db.settings || {}) };
  for (const k of ['games', 'apps', 'sites']) if (!Array.isArray(db[k])) db[k] = d[k];
  db.achievements = db.achievements || {};
  db.stats = { ...d.stats, ...(db.stats || {}) };
  return db;
}

function saveDB(db) {
  try {
    if (fs.existsSync(DB_FILE)) fs.copyFileSync(DB_FILE, DB_FILE + '.bak');
    const tmp = DB_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
    fs.renameSync(tmp, DB_FILE);
    return true;
  } catch (e) {
    console.error('saveDB', e);
    return false;
  }
}

// ───────────────────────── Окна ─────────────────────────
let mainWindow = null;
let webWin = null;

function applyAutostart(on) {
  if (!app.isPackaged) return;
  try {
    const exe = process.env.PORTABLE_EXECUTABLE_FILE || process.execPath;
    app.setLoginItemSettings({ openAtLogin: !!on, path: exe });
  } catch (e) { console.error('autostart', e); }
}

function createMain() {
  const db = loadDB();
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 720,
    fullscreen: db.settings.fullscreen !== false,
    frame: false,
    show: false,
    backgroundColor: '#070a12',
    title: 'Nova Console',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  mainWindow.removeMenu();
  mainWindow.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  mainWindow.webContents.on('will-navigate', (e) => e.preventDefault());
  mainWindow.webContents.on('render-process-gone', () => { try { mainWindow.reload(); } catch { /* ignore */ } });
  mainWindow.webContents.on('before-input-event', (e, input) => {
    if (input.type === 'keyDown' && input.key === 'F11') {
      mainWindow.setFullScreen(!mainWindow.isFullScreen());
      e.preventDefault();
    }
  });
  mainWindow.on('closed', () => { mainWindow = null; });
  applyAutostart(db.settings.autostart);
}

function bringBack() {
  if (!mainWindow) return;
  try {
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.show();
    mainWindow.focus();
  } catch { /* ignore */ }
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', bringBack);
  app.whenReady().then(() => {
    Menu.setApplicationMenu(null);
    createMain();
  });
  app.on('window-all-closed', () => app.quit());
}

// ───────────────────────── Общие IPC ─────────────────────────
function safePath(name) { try { return app.getPath(name); } catch { return ''; } }

ipcMain.handle('info', () => ({
  base: pathToFileURL(DATA_DIR).href.replace(/\/?$/, '/'),
  dataDir: DATA_DIR,
  platform: process.platform,
  version: app.getVersion(),
  portable: !!portableDir,
  folders: { videos: safePath('videos'), music: safePath('music'), downloads: safePath('downloads') },
}));

ipcMain.handle('db:load', () => loadDB());
ipcMain.handle('db:save', (_e, db) => saveDB(db));

const FILTERS = {
  exe: [{ name: 'Программы и ярлыки', extensions: ['exe', 'lnk', 'url', 'bat', 'cmd'] }, { name: 'Все файлы', extensions: ['*'] }],
  image: [{ name: 'Изображения', extensions: ['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp', 'ico'] }],
  audio: [{ name: 'Аудио', extensions: ['mp3', 'ogg', 'wav', 'flac', 'm4a', 'opus', 'aac'] }],
};

ipcMain.handle('pick', async (_e, kind) => {
  const opts = kind === 'folder' ? { properties: ['openDirectory'] } : { properties: ['openFile'], filters: FILTERS[kind] || [] };
  const r = await dialog.showOpenDialog(mainWindow, opts);
  return r.canceled || !r.filePaths.length ? null : r.filePaths[0];
});

function newAssetName(ext) {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7) + (ext || '');
}

ipcMain.handle('asset:import', (_e, src) => {
  try {
    const name = newAssetName(path.extname(src).toLowerCase());
    fs.copyFileSync(src, path.join(ASSETS_DIR, name));
    return 'assets/' + name;
  } catch (e) {
    console.error('asset:import', e);
    return null;
  }
});

ipcMain.handle('file:icon', async (_e, p) => {
  try {
    let img = null;
    try { img = await nativeImage.createThumbnailFromPath(p, { width: 256, height: 256 }); } catch { /* не Windows/нет превью */ }
    if (!img || img.isEmpty()) img = await app.getFileIcon(p, { size: 'large' });
    if (!img || img.isEmpty()) return null;
    const name = newAssetName('.png');
    fs.writeFileSync(path.join(ASSETS_DIR, name), img.toPNG());
    return 'assets/' + name;
  } catch (e) {
    return null;
  }
});

ipcMain.handle('shortcut:resolve', (_e, p) => {
  try {
    const ext = path.extname(p).toLowerCase();
    if (ext === '.lnk') {
      const s = shell.readShortcutLink(p);
      return { kind: 'file', target: s.target || '', args: s.args || '', cwd: s.cwd || '' };
    }
    if (ext === '.url') {
      const t = fs.readFileSync(p, 'utf8');
      const m = t.match(/^URL=(.+)$/mi);
      return { kind: 'url', url: m ? m[1].trim() : '' };
    }
  } catch { /* ignore */ }
  return null;
});

ipcMain.handle('data:open', () => shell.openPath(DATA_DIR));

ipcMain.handle('win:fullscreen', (_e, on) => { if (mainWindow) mainWindow.setFullScreen(!!on); return true; });
ipcMain.handle('win:autostart', (_e, on) => { applyAutostart(on); return true; });

ipcMain.handle('power', (_e, action) => {
  const run = (cmd, args) => execFile(cmd, args, { windowsHide: true }, () => {});
  switch (action) {
    case 'shutdown': run('shutdown', ['/s', '/t', '0']); break;
    case 'restart': run('shutdown', ['/r', '/t', '0']); break;
    case 'logoff': run('shutdown', ['/l']); break;
    case 'sleep': run('rundll32.exe', ['powrprof.dll,SetSuspendState', '0,1,0']); break;
    case 'lock': run('rundll32.exe', ['user32.dll,LockWorkStation']); break;
    case 'quit': app.quit(); break;
    default: break;
  }
  return true;
});

// ───────────────────────── Запуск игр и приложений ─────────────────────────
function splitArgs(s) {
  return (String(s || '').match(/"[^"]*"|\S+/g) || []).map((x) => x.replace(/^"|"$/g, ''));
}

function elevated(file, args, cwd) {
  return new Promise((resolve, reject) => {
    const q = (s) => "'" + String(s).replace(/'/g, "''") + "'";
    let cmd = `Start-Process -FilePath ${q(file)} -WorkingDirectory ${q(cwd)} -Verb RunAs`;
    if (args.length) cmd += ` -ArgumentList ${q(args.map((a) => (/\s/.test(a) ? `"${a}"` : a)).join(' '))}`;
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', cmd], { windowsHide: true }, (err) => {
      if (err) reject(new Error('Запуск от имени администратора не удался или был отменён'));
      else resolve();
    });
  });
}

function launchExe(g) {
  return new Promise((resolve, reject) => {
    const cwd = g.cwd && fs.existsSync(g.cwd) ? g.cwd : path.dirname(g.path);
    const args = splitArgs(g.args);
    if (g.admin) { elevated(g.path, args, cwd).then(resolve, reject); return; }
    const ext = path.extname(g.path).toLowerCase();
    let child;
    try {
      child = (ext === '.bat' || ext === '.cmd')
        ? spawn('cmd.exe', ['/c', g.path, ...args], { cwd, detached: true, stdio: 'ignore' })
        : spawn(g.path, args, { cwd, detached: true, stdio: 'ignore' });
    } catch (e) {
      elevated(g.path, args, cwd).then(resolve, reject);
      return;
    }
    child.once('error', () => { elevated(g.path, args, cwd).then(resolve, reject); }); // exe требует права администратора
    child.once('spawn', () => { child.unref(); resolve(); });
  });
}

function startDetachedShell(target, args) {
  // для системных команд: explorer.exe, taskmgr.exe, любые приложения из PATH
  const child = spawn('cmd.exe', ['/c', 'start', '""', `"${target}"`, ...splitArgs(args).map((a) => `"${a}"`)], {
    detached: true, stdio: 'ignore', windowsHide: true, windowsVerbatimArguments: true,
  });
  child.unref();
}

ipcMain.handle('app:launch', async (_e, a) => {
  try {
    if (a.kind === 'cmd') {
      if (/^[a-z][a-z0-9+.-]+:/i.test(a.target) && !/^[a-z]:[\\/]/i.test(a.target)) await shell.openExternal(a.target);
      else startDetachedShell(a.target, a.args);
    } else if (a.kind === 'exe') {
      if (!fs.existsSync(a.target)) return { ok: false, error: 'Файл не найден: ' + a.target };
      await launchExe({ path: a.target, args: a.args, cwd: a.cwd, admin: a.admin });
    } else if (a.kind === 'url') {
      await shell.openExternal(a.target);
    } else {
      return { ok: false, error: 'Неизвестный тип' };
    }
    return { ok: true };
  } catch (e) {
    return { ok: false, error: String(e.message || e) };
  }
});

// ── Учёт времени в игре ──
const sessions = new Map();

function tasklist() {
  return new Promise((resolve) => {
    execFile('tasklist', ['/FO', 'CSV', '/NH'], { windowsHide: true, maxBuffer: 16 * 1024 * 1024 }, (err, out) => {
      if (err) return resolve(null);
      const set = new Set();
      for (const line of out.split(/\r?\n/)) {
        const m = line.match(/^"([^"]+)"/);
        if (m) set.add(m[1].toLowerCase());
      }
      resolve(set);
    });
  });
}

function steamRunningId() {
  return new Promise((resolve) => {
    execFile('reg', ['query', 'HKCU\\Software\\Valve\\Steam', '/v', 'RunningAppID'], { windowsHide: true }, (err, out) => {
      if (err || !out) return resolve(null);
      const m = out.match(/RunningAppID\s+REG_DWORD\s+0x([0-9a-f]+)/i);
      resolve(m ? String(parseInt(m[1], 16)) : null);
    });
  });
}

function startTracking(g) {
  if (process.platform !== 'win32') return;
  if (sessions.has(g.id)) return;
  const names = [];
  if (g.type === 'exe') {
    const custom = String(g.process || '').split(/[,;]/).map((s) => s.trim().toLowerCase()).filter(Boolean);
    if (custom.length) names.push(...custom.map((n) => (n.endsWith('.exe') ? n : n + '.exe')));
    else names.push(path.basename(g.path).toLowerCase());
  }
  const s = { id: g.id, type: g.type, appid: String(g.appid || ''), names, t0: Date.now(), started: 0, last: 0, miss: 0, timer: null };
  sessions.set(g.id, s);

  const finish = () => {
    clearTimeout(s.timer);
    sessions.delete(g.id);
    const seconds = s.started ? Math.round((s.last - s.started) / 1000) : 0;
    if (mainWindow) mainWindow.webContents.send('game:ended', { id: g.id, seconds, startedAt: s.started });
    if (s.started) bringBack();
  };

  const tick = async () => {
    let running = false;
    if (s.type === 'steam') running = (await steamRunningId()) === s.appid;
    else { const set = await tasklist(); running = !!set && s.names.some((n) => set.has(n)); }
    const now = Date.now();
    if (running) {
      if (!s.started) { s.started = now; if (mainWindow) mainWindow.webContents.send('game:started', { id: g.id }); }
      s.last = now; s.miss = 0;
    } else if (s.started) {
      s.miss += 1;
      if (s.miss >= 3) return finish();
    } else if (now - s.t0 > 120000) {
      return finish(); // процесс не появился — время не считаем
    }
    s.timer = setTimeout(tick, 5000);
  };
  s.timer = setTimeout(tick, 4000);
}

ipcMain.handle('game:launch', async (_e, g) => {
  try {
    if (g.type === 'steam') {
      if (!g.appid) return { ok: false, error: 'Не указан Steam AppID' };
      await shell.openExternal(`steam://rungameid/${g.appid}`);
    } else if (g.type === 'url') {
      if (!g.path) return { ok: false, error: 'Не указана ссылка' };
      await shell.openExternal(g.path);
    } else {
      if (!g.path || !fs.existsSync(g.path)) return { ok: false, error: 'Файл игры не найден: ' + (g.path || '—') };
      await launchExe(g);
    }
    startTracking(g);
    return { ok: true };
  } catch (e) {
    return { ok: false, error: String(e.message || e) };
  }
});

// ───────────────────────── Steam ─────────────────────────
function regSteamPath() {
  return new Promise((resolve) => {
    execFile('reg', ['query', 'HKCU\\Software\\Valve\\Steam', '/v', 'SteamPath'], { windowsHide: true }, (err, out) => {
      const m = !err && out && out.match(/SteamPath\s+REG_SZ\s+(.+)/);
      resolve(m ? m[1].trim().replace(/\//g, '\\') : null);
    });
  });
}

async function steamRoot() {
  let p = process.platform === 'win32' ? await regSteamPath() : null;
  if (!p || !fs.existsSync(p)) {
    p = null;
    for (const c of ['C:\\Program Files (x86)\\Steam', 'C:\\Program Files\\Steam', 'D:\\Steam', 'E:\\Steam']) {
      if (fs.existsSync(c)) { p = c; break; }
    }
  }
  return p;
}

async function steamLibraries() {
  const root = await steamRoot();
  if (!root) return { root: null, libs: [] };
  const libs = new Set([root]);
  try {
    const vdf = fs.readFileSync(path.join(root, 'steamapps', 'libraryfolders.vdf'), 'utf8');
    for (const m of vdf.matchAll(/"path"\s+"([^"]+)"/g)) libs.add(m[1].replace(/\\\\/g, '\\'));
  } catch { /* нет файла */ }
  return { root, libs: [...libs] };
}

ipcMain.handle('steam:scan', async () => {
  const { root, libs } = await steamLibraries();
  const games = [];
  const seen = new Set();
  for (const lib of libs) {
    const dir = path.join(lib, 'steamapps');
    let files = [];
    try { files = fs.readdirSync(dir).filter((f) => /^appmanifest_\d+\.acf$/.test(f)); } catch { continue; }
    for (const f of files) {
      try {
        const t = fs.readFileSync(path.join(dir, f), 'utf8');
        const appid = (t.match(/"appid"\s+"(\d+)"/) || [])[1];
        const name = (t.match(/"name"\s+"([^"]*)"/) || [])[1];
        if (!appid || !name || seen.has(appid)) continue;
        if (/Steamworks Common|Proton|Steam Linux Runtime|Redistributable|Steam Deck/i.test(name)) continue;
        seen.add(appid);
        games.push({ appid, name });
      } catch { /* битый манифест */ }
    }
  }
  games.sort((a, b) => a.name.localeCompare(b.name));
  return { found: !!root, games };
});

function findFile(dir, file, depth = 3) {
  try {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, e.name);
      if (e.isFile() && e.name.toLowerCase() === file) return p;
      if (e.isDirectory() && depth > 0) { const r = findFile(p, file, depth - 1); if (r) return r; }
    }
  } catch { /* ignore */ }
  return null;
}

async function download(urls) {
  for (const u of urls) {
    try {
      const r = await net.fetch(u, { signal: AbortSignal.timeout(9000) });
      if (!r.ok) continue;
      const buf = Buffer.from(await r.arrayBuffer());
      if (buf.length < 1500) continue;
      const name = newAssetName(path.extname(new URL(u).pathname) || '.jpg');
      fs.writeFileSync(path.join(ASSETS_DIR, name), buf);
      return 'assets/' + name;
    } catch { /* следующий URL */ }
  }
  return null;
}

async function steamArt(appid) {
  const root = await steamRoot();
  const cache = root ? path.join(root, 'appcache', 'librarycache') : null;
  const want = { icon: ['library_600x900', 'jpg'], hero: ['library_hero', 'jpg'], logo: ['logo', 'png'] };
  const out = { icon: null, hero: null, logo: null };
  for (const [k, [base, ext]] of Object.entries(want)) {
    let src = null;
    if (cache && fs.existsSync(cache)) {
      const flat = path.join(cache, `${appid}_${base}.${ext}`);
      if (fs.existsSync(flat)) src = flat;
      else {
        const d = path.join(cache, String(appid));
        if (fs.existsSync(d)) src = findFile(d, `${base}.${ext}`);
      }
    }
    if (src) {
      const name = newAssetName('.' + ext);
      fs.copyFileSync(src, path.join(ASSETS_DIR, name));
      out[k] = 'assets/' + name;
    } else {
      out[k] = await download([
        `https://shared.cloudflare.steamstatic.com/store_item_assets/steam/apps/${appid}/${base}.${ext}`,
        `https://cdn.cloudflare.steamstatic.com/steam/apps/${appid}/${base}.${ext}`,
        `https://cdn.akamai.steamstatic.com/steam/apps/${appid}/${base}.${ext}`,
      ]);
    }
  }
  return out;
}

ipcMain.handle('steam:art', (_e, appid) => steamArt(appid));

ipcMain.handle('steam:find', async (_e, name) => {
  try {
    const r = await net.fetch(`https://store.steampowered.com/api/storesearch/?term=${encodeURIComponent(name)}&l=russian&cc=ru`, { signal: AbortSignal.timeout(9000) });
    const j = await r.json();
    const it = j && j.items && j.items[0];
    if (!it) return { ok: false, error: 'В Steam ничего не найдено по этому названию' };
    const art = await steamArt(it.id);
    return { ok: true, appid: String(it.id), name: it.name, ...art };
  } catch (e) {
    return { ok: false, error: 'Нет доступа к Steam (проверь интернет)' };
  }
});

// ───────────────────────── Встроенный браузер ─────────────────────────
function openWeb(url) {
  if (webWin && !webWin.isDestroyed()) {
    webWin.loadURL(url);
    webWin.focus();
    return;
  }
  const ses = session.fromPartition('persist:web');
  ses.setUserAgent(CHROME_UA);
  ses.setPermissionRequestHandler((_wc, perm, cb) => cb(['fullscreen', 'clipboard-sanitized-write', 'pointerLock', 'media'].includes(perm)));
  webWin = new BrowserWindow({
    width: 1280,
    height: 720,
    fullscreen: mainWindow ? mainWindow.isFullScreen() : true,
    frame: false,
    backgroundColor: '#000000',
    webPreferences: {
      partition: 'persist:web',
      preload: path.join(__dirname, 'browser-preload.js'),
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
    },
  });
  webWin.removeMenu();
  webWin.webContents.setUserAgent(CHROME_UA);
  webWin.webContents.setWindowOpenHandler(({ url: u }) => { webWin.loadURL(u); return { action: 'deny' }; });
  webWin.webContents.on('before-input-event', (e, input) => {
    if (input.type === 'keyDown' && (input.key === 'F10' || (input.control && input.key.toLowerCase() === 'w'))) {
      webWin.close();
      e.preventDefault();
    }
  });
  webWin.on('closed', () => { webWin = null; bringBack(); });
  webWin.loadURL(url);
}

ipcMain.handle('web:open', (_e, { url, embedded }) => {
  let u = String(url || '').trim();
  if (!u) return false;
  if (!/^[a-z][a-z0-9+.-]*:/i.test(u)) u = 'https://' + u;
  if (embedded === false) { shell.openExternal(u); return true; }
  openWeb(u);
  return true;
});

ipcMain.on('web:input', (e, m) => {
  const wc = e.sender;
  if (!webWin || webWin.isDestroyed() || wc !== webWin.webContents) return;
  const hist = wc.navigationHistory;
  switch (m.t) {
    case 'move': wc.sendInputEvent({ type: 'mouseMove', x: m.x, y: m.y }); break;
    case 'click':
      wc.sendInputEvent({ type: 'mouseMove', x: m.x, y: m.y });
      wc.sendInputEvent({ type: 'mouseDown', x: m.x, y: m.y, button: 'left', clickCount: 1 });
      wc.sendInputEvent({ type: 'mouseUp', x: m.x, y: m.y, button: 'left', clickCount: 1 });
      break;
    case 'text': wc.insertText(m.text); break;
    case 'key':
      wc.sendInputEvent({ type: 'keyDown', keyCode: m.key });
      if (m.key === 'Enter') wc.sendInputEvent({ type: 'char', keyCode: '\r' });
      wc.sendInputEvent({ type: 'keyUp', keyCode: m.key });
      break;
    case 'back': if (hist.canGoBack()) hist.goBack(); else webWin.close(); break;
    case 'forward': if (hist.canGoForward()) hist.goForward(); break;
    case 'reload': wc.reload(); break;
    case 'close': webWin.close(); break;
    default: break;
  }
});

// ───────────────────────── Медиа ─────────────────────────
const MEDIA_EXT = new Set(['.mp4', '.m4v', '.webm', '.mkv', '.mov', '.mp3', '.ogg', '.wav', '.flac', '.m4a', '.opus', '.aac']);
const VIDEO_EXT = new Set(['.mp4', '.m4v', '.webm', '.mkv', '.mov']);

ipcMain.handle('media:scan', (_e, dir) => {
  const out = [];
  const walk = (d, depth) => {
    let entries = [];
    try { entries = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
    entries.sort((a, b) => a.name.localeCompare(b.name, 'ru', { numeric: true }));
    for (const e of entries) {
      if (out.length >= 800) return;
      const p = path.join(d, e.name);
      if (e.isDirectory() && depth < 3) walk(p, depth + 1);
      else if (e.isFile()) {
        const ext = path.extname(e.name).toLowerCase();
        if (MEDIA_EXT.has(ext)) out.push({ name: path.basename(e.name, ext), url: pathToFileURL(p).href, video: VIDEO_EXT.has(ext) });
      }
    }
  };
  walk(dir, 0);
  return out;
});
