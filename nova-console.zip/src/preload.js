'use strict';
const { contextBridge, ipcRenderer, webUtils } = require('electron');

const inv = (ch) => (...a) => ipcRenderer.invoke(ch, ...a);

contextBridge.exposeInMainWorld('api', {
  info: inv('info'),
  loadDB: inv('db:load'),
  saveDB: inv('db:save'),
  pick: inv('pick'),
  importAsset: inv('asset:import'),
  fileIcon: inv('file:icon'),
  resolveShortcut: inv('shortcut:resolve'),
  launchGame: inv('game:launch'),
  launchApp: inv('app:launch'),
  steamScan: inv('steam:scan'),
  steamArt: inv('steam:art'),
  steamFind: inv('steam:find'),
  openWeb: inv('web:open'),
  mediaScan: inv('media:scan'),
  power: inv('power'),
  setFullscreen: inv('win:fullscreen'),
  setAutostart: inv('win:autostart'),
  openDataDir: inv('data:open'),
  pathForFile: (f) => { try { return webUtils.getPathForFile(f); } catch { return ''; } },
  onGameStarted: (cb) => ipcRenderer.on('game:started', (_e, d) => cb(d)),
  onGameEnded: (cb) => ipcRenderer.on('game:ended', (_e, d) => cb(d)),
});
