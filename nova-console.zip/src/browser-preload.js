'use strict';
// Прелоад встроенного браузера: управление геймпадом (курсор, прокрутка, клики, мини-клавиатура).
const { ipcRenderer } = require('electron');

const send = (m) => ipcRenderer.send('web:input', m);
let cx = 400, cy = 300;
let cursor, hint, kb, kbRows = [], kbSel = [1, 0], kbOpen = false, kbLang = 'ru', kbShift = false;
const prev = {};
const rep = {};

const LAYOUTS = {
  ru: ['1234567890', 'йцукенгшщзхъ', 'фывапролджэ', 'ячсмитьбю.,', '/:@-_?=&%'],
  en: ['1234567890', 'qwertyuiop', 'asdfghjkl', 'zxcvbnm.,', '/:@-_?=&%'],
};

function ready(fn) {
  if (document.readyState !== 'loading') fn();
  else document.addEventListener('DOMContentLoaded', fn);
}

function mk(tag, css, text) {
  const e = document.createElement(tag);
  e.style.cssText = css || '';
  if (text) e.textContent = text;
  return e;
}

function buildKb() {
  kb = mk('div', 'position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:2147483647;background:rgba(10,14,24,.96);border:1px solid rgba(255,255,255,.2);border-radius:16px;padding:14px;display:none;font:600 18px "Segoe UI",sans-serif;color:#fff;box-shadow:0 10px 50px rgba(0,0,0,.6)');
  kb.id = '__nova_kb';
  renderKb();
  document.documentElement.append(kb);
}

function renderKb() {
  kb.innerHTML = '';
  kbRows = [];
  const rows = LAYOUTS[kbLang].map((r) => [...r].map((c) => ({ label: kbShift ? c.toUpperCase() : c, act: 'ch', v: kbShift ? c.toUpperCase() : c })));
  rows.push([
    { label: '⇧', act: 'shift' },
    { label: kbLang === 'ru' ? 'RU' : 'EN', act: 'lang' },
    { label: 'пробел', act: 'ch', v: ' ', wide: 5 },
    { label: '⌫', act: 'bs' },
    { label: '⏎', act: 'enter' },
    { label: 'Скрыть', act: 'hide', wide: 2 },
  ]);
  rows.forEach((r, ri) => {
    const line = mk('div', 'display:flex;gap:6px;margin:6px 0;justify-content:center');
    kbRows.push(r);
    r.forEach((k, ci) => {
      const el = mk('div', `min-width:${(k.wide || 1) * 46}px;height:46px;border-radius:10px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.1);padding:0 8px`, k.label);
      k.el = el;
      line.append(el);
    });
    kb.append(line);
  });
  paintKb();
}

function paintKb() {
  kbRows.forEach((r, ri) => r.forEach((k, ci) => {
    const on = ri === kbSel[0] && ci === kbSel[1];
    k.el.style.background = on ? '#fff' : 'rgba(255,255,255,.1)';
    k.el.style.color = on ? '#111' : '#fff';
  }));
}

function kbMove(dx, dy) {
  let [r, c] = kbSel;
  r = Math.max(0, Math.min(kbRows.length - 1, r + dy));
  c = Math.max(0, Math.min(kbRows[r].length - 1, (dy ? Math.min(c, kbRows[r].length - 1) : c + dx)));
  kbSel = [r, c];
  paintKb();
}

function kbPress() {
  const k = kbRows[kbSel[0]][kbSel[1]];
  if (!k) return;
  if (k.act === 'ch') { send({ t: 'text', text: k.v }); if (kbShift) { kbShift = false; renderKb(); } }
  else if (k.act === 'bs') send({ t: 'key', key: 'Backspace' });
  else if (k.act === 'enter') send({ t: 'key', key: 'Enter' });
  else if (k.act === 'shift') { kbShift = !kbShift; renderKb(); }
  else if (k.act === 'lang') { kbLang = kbLang === 'ru' ? 'en' : 'ru'; renderKb(); }
  else if (k.act === 'hide') toggleKb(false);
}

function toggleKb(on) {
  kbOpen = on === undefined ? !kbOpen : on;
  kb.style.display = kbOpen ? 'block' : 'none';
  if (kbOpen) { kbSel = [1, 0]; paintKb(); }
}

function scrollAt(dy) {
  let el = document.elementFromPoint(cx, cy);
  while (el && el !== document.body && el !== document.documentElement) {
    const cs = getComputedStyle(el);
    if (/(auto|scroll)/.test(cs.overflowY) && el.scrollHeight > el.clientHeight + 2) { el.scrollBy(0, dy); return; }
    el = el.parentElement;
  }
  (document.scrollingElement || document.documentElement).scrollBy(0, dy);
}

function edge(id, now) {
  const was = prev[id];
  prev[id] = now;
  return now && !was;
}

function held(id, now, t) {
  if (!now) { rep[id] = 0; return false; }
  if (!rep[id]) { rep[id] = t + 380; return true; }
  if (t > rep[id]) { rep[id] = t + 110; return true; }
  return false;
}

function tick(t) {
  const pads = navigator.getGamepads ? navigator.getGamepads() : [];
  let gp = null;
  for (const p of pads) if (p && p.connected) { gp = p; break; }
  if (gp && document.hasFocus()) {
    const b = (i) => !!(gp.buttons[i] && gp.buttons[i].pressed);
    const ax = (i) => { const v = gp.axes[i] || 0; return Math.abs(v) < 0.16 ? 0 : v; };
    const up = b(12), down = b(13), left = b(14), right = b(15);
    if (kbOpen) {
      if (held('u', up, t)) kbMove(0, -1);
      if (held('d', down, t)) kbMove(0, 1);
      if (held('l', left, t)) kbMove(-1, 0);
      if (held('r', right, t)) kbMove(1, 0);
      if (edge('x', b(0))) kbPress();
      if (edge('o', b(1))) toggleKb(false);
      if (edge('sq', b(2))) send({ t: 'key', key: 'Backspace' });
      if (edge('tr', b(3))) send({ t: 'text', text: ' ' });
    } else {
      const lx = ax(0), ly = ax(1), ry = ax(3);
      if (lx || ly) {
        const sp = 14;
        cx = Math.max(0, Math.min(innerWidth - 1, cx + lx * Math.abs(lx) * sp));
        cy = Math.max(0, Math.min(innerHeight - 1, cy + ly * Math.abs(ly) * sp));
        cursor.style.transform = `translate(${cx}px,${cy}px)`;
        send({ t: 'move', x: Math.round(cx), y: Math.round(cy) });
      }
      if (ry) scrollAt(ry * Math.abs(ry) * 34);
      if (held('u', up, t)) scrollAt(-140);
      if (held('d', down, t)) scrollAt(140);
      if (edge('x', b(0))) send({ t: 'click', x: Math.round(cx), y: Math.round(cy) });
      if (edge('o', b(1))) send({ t: 'back' });
      if (edge('tr', b(3))) send({ t: 'close' });
      if (edge('sq', b(2))) toggleKb(true);
      if (edge('l1', b(4))) send({ t: 'back' });
      if (edge('r1', b(5))) send({ t: 'forward' });
      if (edge('l3', b(10))) send({ t: 'reload' });
      if (edge('opt', b(9))) hint.style.opacity = hint.style.opacity === '0' ? '1' : '0';
      if (edge('ps', b(16))) send({ t: 'close' });
    }
  }
  requestAnimationFrame(tick);
}

ready(() => {
  cx = innerWidth / 2; cy = innerHeight / 2;
  cursor = mk('div', 'position:fixed;left:-11px;top:-11px;width:22px;height:22px;border-radius:50%;border:3px solid #fff;background:rgba(61,139,255,.55);box-shadow:0 0 0 2px rgba(0,0,0,.55);pointer-events:none;z-index:2147483647;transform:translate(' + cx + 'px,' + cy + 'px)');
  hint = mk('div', 'position:fixed;left:50%;bottom:10px;transform:translateX(-50%);z-index:2147483646;background:rgba(10,14,24,.85);color:#fff;padding:8px 18px;border-radius:999px;font:500 15px "Segoe UI",sans-serif;pointer-events:none;transition:opacity .4s;white-space:nowrap',
    'Левый стик — курсор · Правый стик / ↑↓ — прокрутка · ✕ клик · ○ назад · □ клавиатура · △ закрыть · L1/R1 назад/вперёд · Options — скрыть подсказку');
  document.documentElement.append(cursor, hint);
  buildKb();
  setTimeout(() => { hint.style.opacity = '0'; }, 7000);
  window.addEventListener('keydown', (e) => { if (e.key === 'Escape' && e.ctrlKey) send({ t: 'close' }); }, true);
  requestAnimationFrame(tick);
});
