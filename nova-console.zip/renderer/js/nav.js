'use strict';
// ───── Слои, пространственная навигация, ввод (DualSense / клавиатура / мышь), экранная клавиатура ─────
const isText = (el) => el && el.tagName === 'INPUT' && /^(text|search|url|)$/.test(el.getAttribute('type') || '');
const rem = () => parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;

const Nav = {
  layers: [],
  mode: 'kb', // 'pad' | 'kb' | 'mouse'

  top() { return this.layers[this.layers.length - 1]; },

  root() { const t = this.top(); return t ? t.el : $('#shell'); },

  list() {
    return $$('.f', this.root()).filter((el) => !el.disabled && el.getClientRects().length > 0);
  },

  setMode(m) {
    if (this.mode === m) return;
    this.mode = m;
    document.body.classList.toggle('hide-cursor', m !== 'mouse');
    document.body.classList.toggle('padmode', m === 'pad');
    updateHints();
  },

  // ── слои (модальные окна) ──
  openLayer(el, opts = {}) {
    const layer = { el, onBack: opts.onBack, onClose: opts.onClose, prev: document.activeElement };
    $('#layers').append(el);
    this.layers.push(layer);
    $('#shell').classList.add('dim');
    requestAnimationFrame(() => el.classList.add('show'));
    const first = (opts.focus && $(opts.focus, el)) || $('[data-autofocus]', el) || this.list()[0];
    if (first) first.focus({ preventScroll: true });
    updateHints();
    return layer;
  },

  closeLayer(el) {
    const i = this.layers.findIndex((l) => l.el === el);
    if (i < 0) return;
    const [layer] = this.layers.splice(i, 1);
    el.classList.remove('show');
    setTimeout(() => el.remove(), 180);
    if (!this.layers.length) $('#shell').classList.remove('dim');
    if (layer.onClose) layer.onClose();
    if (i === this.layers.length) { // закрыли верхний — вернуть фокус
      const p = layer.prev;
      if (p && document.body.contains(p) && p.getClientRects().length) p.focus({ preventScroll: true });
      else this.focusDefault();
    }
    updateHints();
  },

  focusDefault() {
    const t = this.top();
    if (t) { const f = $('[data-autofocus]', t.el) || this.list()[0]; if (f) f.focus({ preventScroll: true }); return; }
    const d = Panels.defaultFocus();
    if (d) d.focus({ preventScroll: true });
  },

  focusEl(el, sound = true) {
    if (!el) return;
    el.focus({ preventScroll: true });
    this.reveal(el);
    if (sound) UiSound.move();
  },

  reveal(el) {
    const row = el.closest('.row');
    if (row) {
      row.scrollTo({ left: Math.max(0, el.offsetLeft - rem() * 4), behavior: 'smooth' });
      return;
    }
    el.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' });
  },

  // ── перемещение фокуса ──
  move(dir) {
    const cur = document.activeElement && document.activeElement.classList && document.activeElement.classList.contains('f') ? document.activeElement : null;
    const layered = !!this.top();
    let list = this.list();
    if (!list.length) return;
    if (!cur || !list.includes(cur)) { this.focusDefault(); return; }

    if (cur._nav && cur._nav[dir]) {
      const t = cur._nav[dir]();
      if (t) { this.focusEl(t); return; }
    }
    const inTop = !layered && !!cur.closest('#topbar');
    if (!layered && inTop && dir === 'down') {
      const d = Panels.defaultFocus();
      if (d) { this.focusEl(d); return; }
    }
    if (!layered && !inTop) list = list.filter((el) => !el.closest('#topbar'));

    const r = cur.getBoundingClientRect();
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    let best = null, bs = Infinity;
    for (const el of list) {
      if (el === cur) continue;
      const b = el.getBoundingClientRect();
      const ex = b.left + b.width / 2, ey = b.top + b.height / 2;
      const dx = ex - cx, dy = ey - cy;
      let main, cross;
      if (dir === 'right') { if (dx <= 4) continue; main = dx; cross = Math.abs(dy); }
      else if (dir === 'left') { if (dx >= -4) continue; main = -dx; cross = Math.abs(dy); }
      else if (dir === 'down') { if (dy <= 4) continue; main = dy; cross = Math.abs(dx); }
      else { if (dy >= -4) continue; main = -dy; cross = Math.abs(dx); }
      const score = main + cross * 2.2;
      if (score < bs) { bs = score; best = el; }
    }
    if (best) { this.focusEl(best); return; }
    if (!layered && !inTop && dir === 'up') {
      const tab = $(`.tab[data-tab="${App.tab}"]`);
      if (tab) this.focusEl(tab);
    }
  },

  confirm() {
    const el = document.activeElement;
    if (!el || el === document.body || !el.classList.contains('f')) { this.focusDefault(); return; }
    if (isText(el)) {
      if (this.mode === 'pad') VK.open(el);
      return;
    }
    UiSound.ok();
    rumble(18, 0.35);
    el.click();
  },

  back() {
    if (VK.el) { VK.close(); return; }
    const t = this.top();
    if (t) {
      UiSound.back();
      if (t.onBack) t.onBack(); else this.closeLayer(t.el);
      return;
    }
    const el = document.activeElement;
    if (el && !el.closest('#topbar')) {
      const tab = $(`.tab[data-tab="${App.tab}"]`);
      if (tab) { UiSound.back(); this.focusEl(tab, false); }
    }
  },

  options() {
    if (VK.el) { VK.close(); return; }
    const el = document.activeElement;
    if (el && el._options) { UiSound.ok(); el._options(); }
  },

  act(a) {
    switch (a) {
      case 'up': case 'down': case 'left': case 'right': this.move(a); break;
      case 'confirm': this.confirm(); break;
      case 'back': this.back(); break;
      case 'options': this.options(); break;
      case 'triangle': if (VK.el) VK.space(); else this.options(); break;
      case 'square': if (VK.el) VK.bs(); break;
      case 'prevTab': if (!this.top()) App.cycleTab(-1); break;
      case 'nextTab': if (!this.top()) App.cycleTab(1); break;
      case 'ps': if (!this.top() || !this.top().el.classList.contains('quick')) Quick.open(); break;
      default: break;
    }
  },
};

function rumble(ms, mag) {
  try {
    const gp = [...navigator.getGamepads()].find((g) => g && g.connected);
    if (gp && gp.vibrationActuator) gp.vibrationActuator.playEffect('dual-rumble', { duration: ms, strongMagnitude: 0, weakMagnitude: mag });
  } catch { /* не поддерживается */ }
}

// ───── Клавиатура ─────
window.addEventListener('keydown', (e) => {
  Nav.setMode('kb');
  const typing = isText(e.target);
  let a = null;
  switch (e.key) {
    case 'ArrowUp': a = 'up'; break;
    case 'ArrowDown': a = 'down'; break;
    case 'ArrowLeft': if (!typing) a = 'left'; break;
    case 'ArrowRight': if (!typing) a = 'right'; break;
    case 'Enter': a = typing ? 'down' : 'confirm'; break;
    case ' ': if (!typing) a = 'confirm'; break;
    case 'Escape': a = 'back'; break;
    case 'Backspace': if (!typing) a = 'back'; break;
    case 'PageUp': a = 'prevTab'; break;
    case 'PageDown': a = 'nextTab'; break;
    case 'F1': a = 'ps'; break;
    case 'F2': case 'ContextMenu': a = 'options'; break;
    default: break;
  }
  if (a) { e.preventDefault(); Nav.act(a); }
}, true);

document.addEventListener('mousemove', () => {
  Nav.setMode('mouse');
  clearTimeout(Nav._mt);
  Nav._mt = setTimeout(() => document.body.classList.add('hide-cursor'), 3500);
});
document.addEventListener('mouseover', (e) => {
  if (Nav.mode !== 'mouse') return;
  const f = e.target.closest && e.target.closest('.f');
  if (!f || f === document.activeElement || isText(document.activeElement) && document.activeElement.value) return;
  if (!Nav.root().contains(f)) return;
  f.focus({ preventScroll: true });
});

// ───── Геймпад (DualSense и любой стандартный) ─────
const Pad = { prev: {}, rep: {}, id: '' };

function readPad(gp) {
  const b = (i) => !!(gp.buttons[i] && gp.buttons[i].pressed);
  let up = b(12), down = b(13), left = b(14), right = b(15);
  if (gp.mapping !== 'standard' && gp.axes.length >= 10) { // «хат» вместо крестовины
    const v = gp.axes[9];
    if (v < 2) {
      const i = Math.round((v + 1) * 3.5);
      up = [0, 1, 7].includes(i); right = [1, 2, 3].includes(i); down = [3, 4, 5].includes(i); left = [5, 6, 7].includes(i);
    }
  }
  const lx = gp.axes[0] || 0, ly = gp.axes[1] || 0;
  if (lx < -0.55) left = true;
  if (lx > 0.55) right = true;
  if (ly < -0.55) up = true;
  if (ly > 0.55) down = true;
  return {
    up, down, left, right,
    confirm: b(0), back: b(1), square: b(2), triangle: b(3),
    l1: b(4), r1: b(5), options: b(9), ps: b(16),
  };
}

function padLoop(t) {
  const gp = [...(navigator.getGamepads ? navigator.getGamepads() : [])].find((g) => g && g.connected);
  if (gp && document.hasFocus()) {
    const s = readPad(gp);
    let any = false;
    for (const k of Object.keys(s)) {
      const now = s[k];
      const dir = k === 'up' || k === 'down' || k === 'left' || k === 'right';
      if (now) any = true;
      if (!now) { Pad.rep[k] = 0; }
      else if (!Pad.prev[k]) {
        if (dir) Pad.rep[k] = t + 360;
        Nav.setMode('pad');
        fire(k);
      } else if (dir && t > Pad.rep[k]) {
        Pad.rep[k] = t + 105;
        fire(k);
      }
      Pad.prev[k] = now;
    }
    if (any) Nav.setMode('pad');
  }
  requestAnimationFrame(padLoop);
}

function fire(k) {
  const map = { l1: 'prevTab', r1: 'nextTab' };
  Nav.act(map[k] || k);
}

// ───── Экранная клавиатура для геймпада ─────
const VK = {
  el: null,
  target: null,
  lang: 'ru',
  shift: false,
  rows: {
    ru: ['1234567890', 'йцукенгшщзхъ', 'фывапролджэ', 'ячсмитьбю.,', '/:@-_?=&%'],
    en: ['1234567890', 'qwertyuiop', 'asdfghjkl', 'zxcvbnm.,', '/:@-_?=&%'],
  },

  open(input) {
    if (this.el) return;
    this.target = input;
    this.el = h('div', { class: 'layer vk-layer' });
    this.build();
    Nav.openLayer(this.el, { onBack: () => this.close(), focus: '.key' });
  },

  build() {
    const el = this.el;
    el.innerHTML = '';
    const preview = h('div', { class: 'vk-preview' }, h('span', { class: 'vk-text' }, this.target.value || ''), h('span', { class: 'vk-caret' }));
    const kb = h('div', { class: 'vk' });
    this.rows[this.lang].forEach((row) => {
      kb.append(h('div', { class: 'vk-row' }, [...row].map((c) => {
        const ch = this.shift ? c.toUpperCase() : c;
        return h('button', { class: 'f key', onClick: () => this.ins(ch) }, ch);
      })));
    });
    kb.append(h('div', { class: 'vk-row' },
      h('button', { class: 'f key wide' + (this.shift ? ' on' : ''), onClick: () => { this.shift = !this.shift; this.rebuild(); } }, '⇧'),
      h('button', { class: 'f key wide', onClick: () => { this.lang = this.lang === 'ru' ? 'en' : 'ru'; this.rebuild(); } }, this.lang === 'ru' ? 'RU' : 'EN'),
      h('button', { class: 'f key space', onClick: () => this.ins(' ') }, 'пробел'),
      h('button', { class: 'f key wide', onClick: () => this.bs() }, '⌫'),
      h('button', { class: 'f key done', onClick: () => this.close() }, 'Готово'),
    ));
    el.append(h('div', { class: 'vk-wrap' }, preview, kb));
  },

  rebuild() {
    const cur = document.activeElement;
    const idx = cur && cur.classList.contains('key') ? $$('.key', this.el).indexOf(cur) : 0;
    this.build();
    const keys = $$('.key', this.el);
    (keys[Math.min(idx, keys.length - 1)] || keys[0]).focus({ preventScroll: true });
  },

  refresh() {
    const t = $('.vk-text', this.el);
    if (t) t.textContent = this.target.value || '';
  },

  ins(ch) {
    const t = this.target;
    if (!t) return;
    const s = t.selectionStart == null ? t.value.length : t.selectionStart;
    const e = t.selectionEnd == null ? s : t.selectionEnd;
    t.setRangeText(ch, s, e, 'end');
    t.dispatchEvent(new Event('input', { bubbles: true }));
    UiSound.move();
    if (this.shift) { this.shift = false; this.rebuild(); }
    this.refresh();
  },

  bs() {
    const t = this.target;
    if (!t) return;
    let s = t.selectionStart == null ? t.value.length : t.selectionStart;
    const e = t.selectionEnd == null ? s : t.selectionEnd;
    if (s === e && s > 0) s -= 1;
    if (s === e) return;
    t.setRangeText('', s, e, 'end');
    t.dispatchEvent(new Event('input', { bubbles: true }));
    UiSound.move();
    this.refresh();
  },

  space() { this.ins(' '); },

  close() {
    if (!this.el) return;
    const el = this.el;
    this.el = null;
    Nav.closeLayer(el);
    this.target = null;
  },
};
