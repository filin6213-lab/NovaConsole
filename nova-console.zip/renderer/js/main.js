'use strict';
// ───── Запуск приложения, вкладки, музыка и фон ─────
const App = {
  tab: 'home',
  tabs: ['home', 'games', 'apps', 'sites'],
  names: { home: 'Главная', games: 'Игры', apps: 'Приложения', sites: 'Сайты' },
  focusKey: {},
  dirty: false,

  buildTabs() {
    const nav = $('#tabs');
    nav.innerHTML = '';
    this.tabs.forEach((t) => {
      const b = h('button', { class: 'f tab', 'data-tab': t, onClick: () => { this.setTab(t); const d = Panels.defaultFocus(); if (d) Nav.focusEl(d); } }, this.names[t]);
      b.addEventListener('focus', () => this.setTab(t));
      nav.append(b);
    });
    $('#btnSettings').append(icon('gear'));
    $('#btnPower').append(icon('power'));
    $('#btnSettings').onclick = () => Settings.open();
    $('#btnPower').onclick = () => Quick.open();
  },

  setTab(t) {
    if (t === this.tab && $('#p-' + t).classList.contains('active')) return;
    const changed = t !== this.tab;
    this.tab = t;
    $$('.panel').forEach((p) => p.classList.toggle('active', p.id === 'p-' + t));
    $$('.tab').forEach((b) => b.classList.toggle('active', b.dataset.tab === t));
    Panels.render(t);
    if (changed) UiSound.tab();
    this.updateBg();
    this.updateMusic();
    updateHints();
  },

  cycleTab(d) {
    const i = (this.tabs.indexOf(this.tab) + d + this.tabs.length) % this.tabs.length;
    const next = this.tabs[i];
    const inTop = document.activeElement && document.activeElement.closest && document.activeElement.closest('#topbar');
    this.setTab(next);
    if (inTop) { const tb = $(`.tab[data-tab="${next}"]`); if (tb) tb.focus({ preventScroll: true }); }
    else { const f = Panels.defaultFocus(); if (f) Nav.focusEl(f, false); }
  },

  refresh(focusKey) {
    const ae = document.activeElement;
    const key = focusKey || (ae && ae.dataset && ae.dataset.key && !Nav.top() ? ae.dataset.key : null);
    const topEmpty = !Nav.top();
    Panels.render(this.tab);
    this.updateBg();
    this.updateMusic();
    if (key) {
      const t = $(`#p-${this.tab} [data-key="${key}"]`);
      if (t) {
        if (topEmpty || focusKey) { t.focus({ preventScroll: true }); Nav.reveal(t); }
        return;
      }
    }
    if (topEmpty && ae && ae.closest && ae.closest('.panel')) { const d = Panels.defaultFocus(); if (d) d.focus({ preventScroll: true }); }
  },

  updateBg() {
    const s = S.settings;
    const home = s.bgHome ? assetUrl(s.bgHome) : '';
    if (this.tab === 'games') {
      const g = Games.cur();
      if (g && g.hero) return BG.set(assetUrl(g.hero));
      if (g && g.icon) return BG.set(assetUrl(g.icon), true);
      return BG.set(home);
    }
    if (this.tab === 'home' && !home) {
      const last = sortedGames().find((g) => g.lastPlayed);
      if (last && last.hero) return BG.set(assetUrl(last.hero));
    }
    return BG.set(home);
  },

  updateMusic() {
    if (Media.el) return;
    const s = S.settings;
    let src = '';
    if (this.tab === 'games') {
      const g = Games.cur();
      src = g && g.music ? g.music : s.musicGames;
    } else {
      src = ({ home: s.musicHome, apps: s.musicApps, sites: s.musicSites })[this.tab];
    }
    Music.set(src ? assetUrl(src) : '', this.tab === 'games' ? 450 : 150);
  },
};

// ───── Часы ─────
function tickClock() {
  $('#clock').textContent = new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
  Home.tick();
}

// ───── Перетаскивание файлов в окно ─────
function setupDrop() {
  let depth = 0;
  const dz = $('#dropzone');
  window.addEventListener('dragenter', (e) => { e.preventDefault(); depth++; dz.classList.add('show'); });
  window.addEventListener('dragleave', () => { depth = Math.max(0, depth - 1); if (!depth) dz.classList.remove('show'); });
  window.addEventListener('dragover', (e) => e.preventDefault());
  window.addEventListener('drop', async (e) => {
    e.preventDefault();
    depth = 0;
    dz.classList.remove('show');
    const f = e.dataTransfer.files && e.dataTransfer.files[0];
    if (!f) return;
    const p = api.pathForFile(f);
    if (!p) return;
    if (!/\.(exe|lnk|url|bat|cmd)$/i.test(p)) { toast('Перетащи exe-файл или ярлык игры', { err: true }); return; }
    const v = { type: 'exe', name: '', path: '', args: '', cwd: '', admin: false, process: '', appid: '', icon: '', hero: '', logo: '', music: '', musicName: '' };
    await applyPickedPath(v, p);
    App.setTab('games');
    Games.add(v);
  });
}

// ───── Старт ─────
async function boot() {
  INFO = await api.info();
  S = await api.loadDB();
  UiSound.on = !!S.settings.uiSounds;
  Music.enabled = !!S.settings.music;

  App.buildTabs();
  setupDrop();
  applySettings();
  checkAch(true);

  api.onGameEnded((d) => Games.onEnded(d));
  api.onGameStarted(() => { App.dirty = true; });

  window.addEventListener('blur', () => { document.body.classList.add('blurred'); Music.pause(); });
  window.addEventListener('focus', () => {
    document.body.classList.remove('blurred');
    Music.resume();
    if (App.dirty) { App.dirty = false; App.refresh(); }
  });
  document.addEventListener('focusin', (e) => {
    const k = e.target.dataset && e.target.dataset.key;
    if (k && e.target.closest('.panel')) App.focusKey[App.tab] = k;
  });

  tickClock();
  setInterval(tickClock, 1000);

  App.setTab('home');
  const d = Panels.defaultFocus();
  if (d) d.focus({ preventScroll: true });
  updateHints();
  requestAnimationFrame(padLoop);
  setTimeout(() => document.body.classList.add('ready'), 50);
}

boot().catch((e) => { console.error(e); document.body.append(h('pre', { style: { color: '#f66', padding: '2rem' } }, 'Ошибка запуска: ' + e.message)); });
