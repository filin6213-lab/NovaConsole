'use strict';
// ───── Звуки интерфейса (синтез, без файлов) и фоновая музыка ─────
const UiSound = {
  ctx: null,
  on: true,
  _c() {
    if (!this.ctx) {
      try { this.ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch { /* нет звука */ }
    }
    return this.ctx;
  },
  tone(f, d = 0.06, type = 'sine', g = 0.05, when = 0) {
    if (!this.on) return;
    const c = this._c();
    if (!c) return;
    if (c.state === 'suspended') c.resume();
    const t = c.currentTime + when;
    const o = c.createOscillator();
    const a = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f, t);
    a.gain.setValueAtTime(0.0001, t);
    a.gain.exponentialRampToValueAtTime(g, t + 0.008);
    a.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(a).connect(c.destination);
    o.start(t);
    o.stop(t + d + 0.03);
  },
  move() { this.tone(1250, 0.035, 'sine', 0.03); },
  ok() { this.tone(660, 0.07, 'triangle', 0.06); this.tone(990, 0.12, 'triangle', 0.05, 0.05); },
  back() { this.tone(520, 0.08, 'triangle', 0.05); this.tone(390, 0.1, 'triangle', 0.04, 0.05); },
  tab() { this.tone(820, 0.05, 'sine', 0.04); this.tone(1040, 0.07, 'sine', 0.04, 0.04); },
  error() { this.tone(200, 0.16, 'square', 0.03); },
  trophy() { [880, 1108, 1318, 1760].forEach((f, i) => this.tone(f, 0.28, 'sine', 0.05, i * 0.09)); },
};

const Music = {
  a: null,
  src: '',
  want: '',
  vol: 0.6,
  enabled: true,
  paused: false,
  _t: null,

  set(src, delay = 0) {
    clearTimeout(this._t);
    this.want = src || '';
    this._t = setTimeout(() => this._apply(), delay);
  },

  _apply() {
    if (this.want === this.src) return;
    this.src = this.want;
    const old = this.a;
    this.a = null;
    if (old) this._fade(old, 0, 500, () => { old.pause(); old.removeAttribute('src'); });
    if (!this.want || !this.enabled) return;
    const a = new Audio(this.want);
    a.loop = true;
    a.volume = 0;
    this.a = a;
    a.play().then(() => {
      if (this.paused) a.pause();
      else this._fade(a, this.vol, 800);
    }).catch(() => { /* файл не читается */ });
  },

  _fade(a, to, ms, done) {
    clearInterval(a._f);
    const from = a.volume;
    const t0 = performance.now();
    a._f = setInterval(() => {
      const k = Math.min(1, (performance.now() - t0) / ms);
      a.volume = Math.max(0, Math.min(1, from + (to - from) * k));
      if (k >= 1) { clearInterval(a._f); if (done) done(); }
    }, 30);
  },

  setVolume(v) {
    this.vol = v;
    if (this.a && !this.paused) this._fade(this.a, v, 200);
  },

  setEnabled(on) {
    this.enabled = on;
    const w = this.want;
    this.src = '\0';
    this.want = w;
    if (!on && this.a) { const o = this.a; this.a = null; this._fade(o, 0, 300, () => o.pause()); this.src = w; return; }
    this._apply();
  },

  pause() {
    this.paused = true;
    const a = this.a;
    if (a) this._fade(a, 0, 300, () => { if (this.paused) a.pause(); });
  },

  resume() {
    this.paused = false;
    const a = this.a;
    if (a) { a.play().catch(() => {}); this._fade(a, this.vol, 600); }
  },
};
