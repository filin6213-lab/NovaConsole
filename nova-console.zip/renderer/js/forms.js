'use strict';
// ───── Окна, меню, формы, тосты, подсказки, быстрое меню ─────

function updateHints() {
  const pad = Nav.mode === 'pad';
  const k = (p, kb) => h('b', { class: 'hk' + (pad ? ' pad' : '') }, pad ? p : kb);
  const item = (key, text) => h('span', { class: 'hint' }, key, h('i', {}, text));
  const bar = $('#hints');
  bar.innerHTML = '';
  const top = Nav.top();
  const parts = [];
  if (VK.el) {
    parts.push(item(k('✕', 'Enter'), 'Ввести'), item(k('□', '—'), 'Стереть'), item(k('△', '—'), 'Пробел'), item(k('○', 'Esc'), 'Готово'));
  } else if (top) {
    parts.push(item(k('✕', 'Enter'), 'Выбрать'), item(k('○', 'Esc'), 'Назад'));
  } else {
    parts.push(item(k('✕', 'Enter'), 'Выбрать'));
    const f = document.activeElement;
    if (f && f._options) parts.push(item(k('△', 'F2'), 'Опции'));
    parts.push(item(k('L1 R1', 'PgUp PgDn'), 'Разделы'), item(k('PS', 'F1'), 'Меню'));
  }
  bar.append(...parts);
}
document.addEventListener('focusin', debounce(updateHints, 40));

function toast(text, o = {}) {
  const t = h('div', { class: 'toast' + (o.err ? ' err' : '') + (o.tier ? ' trophy ' + o.tier : '') },
    o.tier ? h('span', { class: 'tcup ' + o.tier }, icon('award')) : null,
    h('div', { class: 'ttxt' }, o.title ? h('b', {}, o.title) : null, h('span', {}, text)));
  $('#toasts').append(t);
  requestAnimationFrame(() => t.classList.add('show'));
  setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 400); }, o.ms || 3800);
}

// ───── базовое окно ─────
function modal({ title, body, buttons = [], wide = false, onBack, cls = '' }) {
  const el = h('div', { class: 'layer ' + cls });
  const foot = h('div', { class: 'sheet-foot' });
  const api2 = {
    el,
    close: () => Nav.closeLayer(el),
  };
  buttons.forEach((b) => foot.append(h('button', {
    class: 'f btn' + (b.primary ? ' primary' : '') + (b.danger ? ' danger' : ''),
    onClick: () => b.onClick(api2),
  }, b.label)));
  el.append(h('div', { class: 'sheet' + (wide ? ' wide' : '') },
    title ? h('div', { class: 'sheet-title' }, title) : null,
    h('div', { class: 'sheet-body' }, body),
    buttons.length ? foot : null));
  Nav.openLayer(el, { onBack: onBack ? () => onBack(api2) : null });
  return api2;
}

function openMenu({ title, items, cls = '' }) {
  const el = h('div', { class: 'layer menu-layer ' + cls });
  const list = h('div', { class: 'menu' });
  const api2 = { el, close: () => Nav.closeLayer(el) };
  items.forEach((it) => {
    if (it.sep) { list.append(h('div', { class: 'menu-sep' })); return; }
    list.append(h('button', {
      class: 'f menu-item' + (it.danger ? ' danger' : '') + (it.sel ? ' sel' : ''),
      disabled: it.disabled,
      onClick: () => { api2.close(); setTimeout(() => it.run && it.run(), 30); },
    }, it.icon ? icon(it.icon) : null, h('span', {}, it.label), it.sel ? h('em', {}, '✓') : null));
  });
  el.append(h('div', { class: 'menu-card' }, title ? h('div', { class: 'menu-title' }, title) : null, list));
  Nav.openLayer(el, { focus: '.menu-item.sel' });
  return api2;
}

function confirmBox(text, okLabel, onOk, danger = true) {
  return modal({
    title: text,
    body: h('div', {}),
    wide: false,
    cls: 'confirm',
    buttons: [
      { label: 'Отмена', onClick: (m) => m.close() },
      { label: okLabel, primary: !danger, danger, onClick: (m) => { m.close(); setTimeout(onOk, 30); } },
    ],
  });
}

// ───── конструктор форм ─────
// fields: { key, label, type: text|toggle|select|file|image|audio|stepper|button|info, ... }
function openForm({ title, fields, values, saveLabel = 'Сохранить', onSave, extra = [] }) {
  const vals = { ...values };
  const body = h('div', { class: 'form' });
  let sheet;

  const pickAsset = async (f) => {
    const p = await api.pick(f.type === 'image' ? 'image' : 'audio');
    if (!p) return;
    const rel = await api.importAsset(p);
    if (rel) { vals[f.key] = rel; vals[f.key + 'Name'] = baseName(p); render(f.key); }
  };

  function row(f) {
    const label = h('div', { class: 'frow-l' }, f.label || '', f.hint ? h('small', {}, f.hint) : null);
    let ctl;
    switch (f.type) {
      case 'text':
        ctl = h('input', {
          class: 'f input', type: 'text', value: vals[f.key] || '', placeholder: f.placeholder || '', spellcheck: 'false',
          'data-k': f.key,
          onInput: (e) => { vals[f.key] = e.target.value; },
        });
        break;
      case 'toggle':
        ctl = h('button', { class: 'f toggle' + (vals[f.key] ? ' on' : ''), 'data-k': f.key, onClick: (e) => {
          vals[f.key] = !vals[f.key];
          e.currentTarget.classList.toggle('on', !!vals[f.key]);
          if (f.onChange) f.onChange(vals, render);
        } }, h('i', {}));
        break;
      case 'select':
        ctl = h('button', { class: 'f btn select', 'data-k': f.key, onClick: () => openMenu({
          title: f.label,
          items: f.options.map((o) => ({ label: o.l, sel: o.v === vals[f.key], run: () => { vals[f.key] = o.v; if (f.onChange) f.onChange(vals, render); render(f.key); } })),
        }) }, (f.options.find((o) => o.v === vals[f.key]) || {}).l || '—', h('em', {}, '▾'));
        break;
      case 'file':
        ctl = h('div', { class: 'filectl' },
          h('input', { class: 'f input', type: 'text', value: vals[f.key] || '', placeholder: f.placeholder || '', spellcheck: 'false', 'data-k': f.key, onInput: (e) => { vals[f.key] = e.target.value; } }),
          h('button', { class: 'f btn', onClick: async () => {
            const p = await api.pick(f.pick || 'exe');
            if (!p) return;
            vals[f.key] = p;
            if (f.after) await f.after(vals, p);
            render(f.key);
          } }, 'Обзор…'));
        break;
      case 'image':
      case 'audio': {
        const has = !!vals[f.key];
        const prev = f.type === 'image'
          ? h('div', { class: 'thumb', style: has ? { backgroundImage: `url("${assetUrl(vals[f.key])}")` } : {} }, has ? null : icon('plus'))
          : h('div', { class: 'thumb aud' }, icon('music'));
        ctl = h('div', { class: 'assetctl' }, prev,
          h('div', { class: 'assetname' }, has ? (vals[f.key + 'Name'] || baseName(vals[f.key])) : 'не выбрано'),
          h('button', { class: 'f btn', 'data-k': f.key, onClick: () => pickAsset(f) }, has ? 'Заменить' : 'Выбрать'),
          has ? h('button', { class: 'f btn', onClick: () => { vals[f.key] = ''; vals[f.key + 'Name'] = ''; render(f.key); } }, 'Убрать') : null);
        break;
      }
      case 'stepper':
        ctl = h('div', { class: 'stepper' },
          h('button', { class: 'f btn round', onClick: () => { vals[f.key] = Math.max(f.min, (vals[f.key] || 0) - f.step); render(f.key + '-'); } }, '−'),
          h('span', { class: 'sval' }, (vals[f.key] || 0) + (f.unit || '')),
          h('button', { class: 'f btn round', 'data-k': f.key + '+', onClick: () => { vals[f.key] = Math.min(f.max, (vals[f.key] || 0) + f.step); render(f.key + '+'); } }, '+'));
        $('.btn', ctl).setAttribute('data-k', f.key + '-');
        break;
      case 'button':
        return h('div', { class: 'frow single' }, h('button', { class: 'f btn wideb', 'data-k': f.key, onClick: async (e) => {
          const b = e.currentTarget;
          b.disabled = true;
          const old = b.textContent;
          b.textContent = 'Подождите…';
          try { await f.run(vals); } finally { b.disabled = false; b.textContent = old; }
          render(f.key);
        } }, f.label));
      case 'info':
        return h('div', { class: 'frow info' }, h('small', {}, f.label));
      default:
        return h('div');
    }
    return h('div', { class: 'frow' }, label, ctl);
  }

  function render(focusKey) {
    const keep = focusKey || (document.activeElement && document.activeElement.dataset ? document.activeElement.dataset.k : null);
    body.innerHTML = '';
    fields.forEach((f) => { if (!f.show || f.show(vals)) body.append(row(f)); });
    if (keep) {
      const t = $(`[data-k="${keep}"]`, body);
      if (t) t.focus({ preventScroll: true });
    }
  }

  render();
  sheet = modal({
    title,
    body,
    wide: true,
    cls: 'formsheet',
    buttons: [
      ...extra,
      { label: 'Отмена', onClick: (m) => m.close() },
      { label: saveLabel, primary: true, onClick: async (m) => {
        const r = await onSave(vals);
        if (r !== false) m.close();
      } },
    ],
  });
  const first = $('.f', body);
  if (first) first.focus({ preventScroll: true });
  return sheet;
}

// ───── быстрое меню (кнопка PS / F1) ─────
const Quick = {
  open() {
    openMenu({
      title: 'Меню',
      cls: 'quick',
      items: [
        { label: 'Продолжить', icon: 'play', run: () => {} },
        { label: 'Настройки', icon: 'gear', run: () => Settings.open() },
        { label: 'Трофеи', icon: 'award', run: () => Achievements.open() },
        { sep: true },
        { label: 'Спящий режим', icon: 'moon', run: () => api.power('sleep') },
        { label: 'Заблокировать', icon: 'lock', run: () => api.power('lock') },
        { label: 'Перезагрузить', icon: 'restart', run: () => confirmBox('Перезагрузить компьютер?', 'Перезагрузить', () => api.power('restart')) },
        { label: 'Выключить', icon: 'power', danger: true, run: () => confirmBox('Выключить компьютер?', 'Выключить', () => api.power('shutdown')) },
        { sep: true },
        { label: 'Выйти из оболочки в Windows', icon: 'logout', run: () => api.power('quit') },
      ],
    });
  },
};
