'use strict';
// ───── Панели: Главная, Игры, Приложения, Сайты + трофеи, настройки, медиаплеер, импорт Steam ─────
let S = null; // база данных (настройки, игры, приложения, сайты, трофеи)

const save = debounce(() => { api.saveDB(S); }, 300);

// ───── Фон (кроссфейд) ─────
const BG = {
  cur: '\0', flip: false,
  set(u, blur) {
    const key = (u || '') + (blur ? '#b' : '');
    if (key === this.cur) return;
    this.cur = key;
    const ls = [$('#bg .a'), $('#bg .b')];
    const next = ls[this.flip ? 0 : 1], prev = ls[this.flip ? 1 : 0];
    this.flip = !this.flip;
    next.style.backgroundImage = u ? `url("${u}")` : 'none';
    next.classList.toggle('blur', !!blur);
    next.classList.toggle('on', !!u);
    prev.classList.remove('on');
  },
};

// ───── Трофеи ─────
const TIERS = { platinum: 'Платиновый', gold: 'Золотой', silver: 'Серебряный', bronze: 'Бронзовый' };
const ACH = [
  { id: 'first_game', t: 'bronze', n: 'Первая игра', d: 'Добавь игру в библиотеку', ok: (t) => t.games >= 1 },
  { id: 'games5', t: 'bronze', n: 'Растущая коллекция', d: 'Добавь 5 игр', ok: (t) => t.games >= 5 },
  { id: 'games15', t: 'silver', n: 'Коллекционер', d: 'Добавь 15 игр', ok: (t) => t.games >= 15 },
  { id: 'games40', t: 'gold', n: 'Библиотекарь', d: 'Добавь 40 игр', ok: (t) => t.games >= 40 },
  { id: 'first_launch', t: 'bronze', n: 'Поехали!', d: 'Запусти любую игру', ok: (t) => t.launches >= 1 },
  { id: 'h10', t: 'bronze', n: 'Втягиваюсь', d: 'Наиграй 10 часов', ok: (t) => t.hours >= 10 },
  { id: 'h50', t: 'silver', n: 'Заядлый игрок', d: 'Наиграй 50 часов', ok: (t) => t.hours >= 50 },
  { id: 'h200', t: 'gold', n: 'Ветеран', d: 'Наиграй 200 часов', ok: (t) => t.hours >= 200 },
  { id: 'marathon', t: 'silver', n: 'Марафонец', d: 'Играй 3 часа подряд', ok: (t) => t.maxSession >= 3 * 3600 },
  { id: 'night', t: 'bronze', n: 'Ночная сова', d: 'Запусти игру между 00:00 и 05:00', ok: (t) => t.night },
  { id: 'streak3', t: 'bronze', n: 'Три дня подряд', d: 'Играй 3 дня подряд', ok: (t) => t.streak >= 3 },
  { id: 'streak7', t: 'silver', n: 'Неделя без пропусков', d: 'Играй 7 дней подряд', ok: (t) => t.streak >= 7 },
  { id: 'style', t: 'bronze', n: 'Дизайнер', d: 'Настрой фон и логотип игры', ok: (t) => t.styled },
  { id: 'music', t: 'bronze', n: 'Меломан', d: 'Добавь игре свою музыку', ok: (t) => t.withMusic },
  { id: 'surf', t: 'bronze', n: 'Сёрфер', d: 'Открой любой сайт', ok: (t) => t.sites },
  { id: 'platinum', t: 'platinum', n: 'Платина', d: 'Получи все остальные трофеи', ok: (t, u) => ACH.filter((a) => a.id !== 'platinum').every((a) => u[a.id]) },
];

function streakDays() {
  const days = new Set(S.stats.days || []);
  let n = 0;
  let ts = Date.now();
  if (!days.has(dayKey(ts))) ts -= 86400000;
  while (days.has(dayKey(ts))) { n++; ts -= 86400000; }
  return n;
}

function totals() {
  const g = S.games;
  const secs = g.reduce((a, x) => a + (x.playSeconds || 0), 0);
  return {
    games: g.length,
    secs,
    hours: secs / 3600,
    launches: g.reduce((a, x) => a + (x.launches || 0), 0),
    streak: streakDays(),
    maxSession: S.stats.maxSession || 0,
    night: !!S.stats.night,
    styled: g.some((x) => x.hero && x.logo),
    withMusic: g.some((x) => x.music),
    sites: !!S.stats.sites,
  };
}

function checkAch(silent) {
  const t = totals();
  const fresh = [];
  let changed = true;
  while (changed) {
    changed = false;
    for (const a of ACH) {
      if (!S.achievements[a.id] && a.ok(t, S.achievements)) {
        S.achievements[a.id] = Date.now();
        fresh.push(a);
        changed = true;
      }
    }
  }
  if (fresh.length) {
    save();
    if (!silent) {
      fresh.forEach((a, i) => setTimeout(() => { toast(a.d, { title: 'Трофей получен: ' + a.n, tier: a.t, ms: 4600 }); UiSound.trophy(); }, i * 1800));
    }
  }
}

function trophyCounts() {
  const c = { platinum: 0, gold: 0, silver: 0, bronze: 0 };
  ACH.forEach((a) => { if (S.achievements[a.id]) c[a.t]++; });
  return c;
}

const Achievements = {
  open() {
    const body = h('div', { class: 'achgrid' });
    const sorted = [...ACH].sort((a, b) => (S.achievements[b.id] ? 1 : 0) - (S.achievements[a.id] ? 1 : 0));
    sorted.forEach((a) => {
      const got = S.achievements[a.id];
      body.append(h('button', { class: 'f ach ' + (got ? 'got ' : 'locked ') + a.t },
        h('span', { class: 'tcup ' + a.t }, icon('award')),
        h('div', {}, h('b', {}, a.n), h('small', {}, a.d), h('em', {}, got ? 'Получен ' + fmtDate(got) : TIERS[a.t])),
      ));
    });
    const c = trophyCounts();
    modal({
      title: `Трофеи — ${Object.values(S.achievements).length} из ${ACH.length}`,
      body: h('div', {},
        h('div', { class: 'trophy-row big' }, ...['platinum', 'gold', 'silver', 'bronze'].map((k) => h('span', { class: 'tr ' + k }, h('span', { class: 'tcup ' + k }, icon('award')), c[k]))),
        body),
      wide: true,
      buttons: [{ label: 'Закрыть', primary: true, onClick: (m) => m.close() }],
    });
  },
};

// ───── Плитки ─────
function gameInitial(g) { return (g.name || '?').trim().charAt(0).toUpperCase(); }
function gameHue(g) { return hashStr(g.name || '') % 360; }

function gameArt(g) {
  const art = h('div', { class: 'art' });
  if (g.icon) art.style.backgroundImage = `url("${assetUrl(g.icon)}")`;
  else if (g.hero) {
    art.style.backgroundImage = `url("${assetUrl(g.hero)}")`;
    art.append(g.logo ? h('img', { class: 'tlogo', src: assetUrl(g.logo), alt: '' }) : h('span', { class: 'tinit' }, gameInitial(g)));
  } else {
    const hue = gameHue(g);
    art.style.background = `linear-gradient(135deg, hsl(${hue},55%,40%), hsl(${(hue + 45) % 360},60%,20%))`;
    art.append(h('span', { class: 'tinit' }, gameInitial(g)));
  }
  return art;
}

function sortedGames() {
  return [...S.games].sort((a, b) => (b.lastPlayed || 0) - (a.lastPlayed || 0) || (b.added || 0) - (a.added || 0));
}

// ───── Формы для игр ─────
async function applyPickedPath(v, p) {
  const lower = p.toLowerCase();
  v.iconAuto = false;
  if (/\.(lnk|url)$/.test(lower)) {
    const r = await api.resolveShortcut(p);
    if (!v.name) v.name = cleanName(stripExt(baseName(p)));
    if (r && r.kind === 'file' && r.target) {
      v.path = r.target; v.args = r.args || ''; v.cwd = r.cwd || '';
      const m = /steam\.exe$/i.test(r.target) && /-applaunch\s+(\d+)/i.exec(r.args || '');
      if (m) { v.type = 'steam'; v.appid = m[1]; v.path = ''; v.args = ''; }
    } else if (r && r.kind === 'url') {
      const m = /^steam:\/\/rungameid\/(\d+)/i.exec(r.url);
      if (m) { v.type = 'steam'; v.appid = m[1]; v.path = ''; } else { v.type = 'url'; v.path = r.url; }
    } else {
      v.path = p;
    }
  } else {
    v.path = p;
    v.cwd = '';
    if (!v.name) v.name = guessGameName(p);
  }
  if (v.type === 'exe' && v.path && !v.icon) {
    const ic = await api.fileIcon(v.path);
    if (ic) { v.icon = ic; v.iconAuto = true; }
  }
}

function gameFields() {
  const isExe = (v) => v.type === 'exe';
  return [
    { key: 'type', type: 'select', label: 'Тип игры', options: [
      { v: 'exe', l: 'Программа / игра (exe, ярлык)' },
      { v: 'steam', l: 'Steam-игра' },
      { v: 'url', l: 'Ссылка (Epic, GOG Galaxy и др.)' },
    ] },
    { key: 'name', type: 'text', label: 'Название', placeholder: 'Например: Portal 2' },
    { key: 'path', type: 'file', label: 'Файл игры', hint: '.exe, ярлык .lnk или .bat — подходит и для пиратских игр', pick: 'exe', show: isExe, after: applyPickedPath },
    { key: 'appid', type: 'text', label: 'Steam AppID', hint: 'число из ссылки на игру в магазине Steam', show: (v) => v.type === 'steam' },
    { key: 'path', type: 'text', label: 'Ссылка запуска', placeholder: 'com.epicgames.launcher://apps/…', show: (v) => v.type === 'url' },
    { key: 'args', type: 'text', label: 'Параметры запуска', placeholder: '-windowed -nolauncher', show: isExe },
    { key: 'admin', type: 'toggle', label: 'Запускать от администратора', hint: 'нужно некоторым играм и пираткам', show: isExe },
    { key: 'process', type: 'text', label: 'Процесс для учёта времени', hint: 'если игра стартует через лаунчер — впиши имя exe самой игры', placeholder: 'game.exe', show: isExe },
    { key: 'steamart', type: 'button', label: 'Подтянуть обложку, фон и логотип из Steam по названию', run: async (v) => {
      const q = (v.name || '').trim();
      if (!q) { toast('Сначала введи название игры', { err: true }); return; }
      const r = await api.steamFind(q);
      if (!r.ok) { toast(r.error, { err: true }); UiSound.error(); return; }
      if (r.hero) v.hero = r.hero;
      if (r.logo) v.logo = r.logo;
      if (r.icon && !r.hero) v.icon = r.icon;
      else if (v.iconAuto) { v.icon = ''; v.iconAuto = false; }
      if (v.type === 'steam' && !v.appid) v.appid = r.appid;
      toast('Найдено в Steam: ' + r.name);
    } },
    { key: 'icon', type: 'image', label: 'Иконка плитки' },
    { key: 'hero', type: 'image', label: 'Фон' },
    { key: 'logo', type: 'image', label: 'Логотип' },
    { key: 'music', type: 'audio', label: 'Музыка при наведении', hint: 'играет в меню, когда выбрана эта игра' },
  ];
}

async function fetchSteamArtFor(g) {
  try {
    const r = await api.steamArt(g.appid);
    if (r.hero) g.hero = r.hero;
    if (r.logo) g.logo = r.logo;
    if (r.icon && !r.hero && !g.icon) g.icon = r.icon;
    save();
    checkAch();
    App.refresh();
  } catch { /* нет сети */ }
}

function saveGameFrom(v, existing) {
  const name = (v.name || '').trim();
  if (!name) { toast('Укажи название игры', { err: true }); UiSound.error(); return false; }
  if (v.type === 'exe' && !v.path) { toast('Выбери файл игры (exe или ярлык)', { err: true }); UiSound.error(); return false; }
  if (v.type === 'steam' && !/^\d+$/.test(String(v.appid || '').trim())) { toast('Steam AppID — это число, например 620', { err: true }); UiSound.error(); return false; }
  if (v.type === 'url' && !v.path) { toast('Укажи ссылку запуска', { err: true }); UiSound.error(); return false; }
  const g = existing || { id: 'g' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), added: Date.now(), playSeconds: 0, launches: 0, lastPlayed: 0 };
  Object.assign(g, {
    name, type: v.type, path: v.path || '', args: v.args || '', cwd: v.cwd || '', admin: !!v.admin,
    process: v.process || '', appid: String(v.appid || '').trim(), icon: v.icon || '', hero: v.hero || '', logo: v.logo || '',
    music: v.music || '', musicName: v.musicName || '',
  });
  if (!existing) S.games.push(g);
  save();
  checkAch();
  Games.selId = g.id;
  App.refresh('g' + g.id);
  if (g.type === 'steam' && g.appid && !g.hero && !g.icon) fetchSteamArtFor(g);
  return true;
}

// ───── Панель «Игры» ─────
const Games = {
  sel: 0,
  selId: null,
  list: [],

  cur() { return this.list[this.sel] || null; },
  currentTile() { return $$('.tile', $('#p-games'))[this.sel]; },

  render() {
    const p = $('#p-games');
    p.innerHTML = '';
    this.list = sortedGames();
    const idx = this.list.findIndex((g) => g.id === this.selId);
    this.sel = idx >= 0 ? idx : Math.min(this.sel, this.list.length);

    const row = h('div', { class: 'row grow', id: 'grow' });
    this.list.forEach((g, i) => {
      const t = h('button', { class: 'f tile', 'data-key': 'g' + g.id, onClick: () => this.launch(g) }, gameArt(g));
      t._options = () => this.options(g);
      t._nav = { down: () => $('#btnPlay') };
      t.addEventListener('focus', () => this.select(i));
      row.append(t);
    });
    const addT = h('button', { class: 'f tile special', 'data-key': 'add', onClick: () => this.add() }, h('div', { class: 'art sp' }, icon('plus')));
    addT._nav = { down: () => $('#btnPlay') };
    addT.addEventListener('focus', () => this.select(this.list.length));
    const stT = h('button', { class: 'f tile special', 'data-key': 'steam', onClick: () => SteamImport.open() }, h('div', { class: 'art sp' }, icon('download')));
    stT._nav = { down: () => $('#btnPlay') };
    stT.addEventListener('focus', () => this.select(this.list.length + 1));
    row.append(addT, stT);

    const info = h('div', { class: 'ginfo', id: 'ginfo' });
    const cards = h('div', { class: 'gcards', id: 'gcards' });
    p.append(row, info, cards);
    this.select(this.sel, true);
  },

  select(i, noScroll) {
    this.sel = i;
    const tiles = $$('.tile', $('#p-games'));
    tiles.forEach((t, k) => t.classList.toggle('sel', k === i));
    const g = this.cur();
    if (g) this.selId = g.id;
    if (!noScroll && tiles[i]) Nav.reveal(tiles[i]);
    this.fillInfo(g, i);
    App.updateBg();
    App.updateMusic();
  },

  fillInfo(g, i) {
    const info = $('#ginfo'), cards = $('#gcards');
    if (!info) return;
    info.innerHTML = '';
    cards.innerHTML = '';
    const tile = () => $$('.tile', $('#p-games'))[this.sel];
    const play = h('button', { class: 'f btn primary big', id: 'btnPlay' });
    play._nav = { up: tile };
    if (g) {
      const typeName = g.type === 'steam' ? 'Steam' : g.type === 'url' ? 'Ссылка' : 'Программа';
      info.append(
        g.logo ? h('img', { class: 'glogo', src: assetUrl(g.logo), alt: g.name }) : h('h1', { class: 'gtitle' }, g.name),
        h('div', { class: 'gsub' }, g.logo ? g.name + ' · ' : '', typeName, g.playSeconds ? ' · ' + fmtHours(g.playSeconds) + ' в игре' : ' · ещё не запускалась'),
      );
      play.append(icon('play'), h('span', {}, 'Играть'));
      play.onclick = () => this.launch(g);
      const more = h('button', { class: 'f btn round', id: 'btnMore', 'aria-label': 'Опции' }, icon('more'));
      more._nav = { up: tile };
      more.onclick = () => this.options(g);
      info.append(h('div', { class: 'gactions' }, play, more));
      cards.append(
        card('Время в игре', fmtHours(g.playSeconds)),
        card('Последний запуск', g.lastPlayed ? fmtDate(g.lastPlayed) : '—'),
        card('Запусков', String(g.launches || 0)),
      );
      if (g.music) cards.append(card('Музыка', g.musicName || 'своя'));
    } else if (i === this.list.length) {
      info.append(h('h1', { class: 'gtitle' }, 'Добавить игру'),
        h('div', { class: 'gsub' }, 'Выбери exe или ярлык игры (в том числе пиратской). Можно просто перетащить файл в окно.'));
      play.append(icon('plus'), h('span', {}, 'Добавить'));
      play.onclick = () => this.add();
      info.append(h('div', { class: 'gactions' }, play));
    } else {
      info.append(h('h1', { class: 'gtitle' }, 'Импорт из Steam'),
        h('div', { class: 'gsub' }, 'Найдём установленные Steam-игры и сами подтянем обложки, фоны и логотипы.'));
      play.append(icon('download'), h('span', {}, 'Импортировать'));
      play.onclick = () => SteamImport.open();
      info.append(h('div', { class: 'gactions' }, play));
    }
  },

  async launch(g) {
    const r = await api.launchGame(g);
    if (!r.ok) { toast(r.error || 'Не удалось запустить', { err: true }); UiSound.error(); return; }
    const now = Date.now();
    g.launches = (g.launches || 0) + 1;
    g.lastPlayed = now;
    const dk = dayKey(now);
    if (!S.stats.days.includes(dk)) S.stats.days.push(dk);
    S.stats.days = S.stats.days.slice(-400);
    const hr = new Date(now).getHours();
    if (hr >= 0 && hr < 5) S.stats.night = true;
    save();
    toast('Запускаю: ' + g.name);
    checkAch();
    App.dirty = true;
  },

  add(prefill) {
    const v = { type: 'exe', name: '', path: '', args: '', cwd: '', admin: false, process: '', appid: '', icon: '', hero: '', logo: '', music: '', musicName: '', ...(prefill || {}) };
    openForm({ title: 'Новая игра', fields: gameFields(), values: v, saveLabel: 'Добавить', onSave: (vals) => saveGameFrom(vals, null) });
  },

  edit(g) {
    openForm({ title: 'Изменить: ' + g.name, fields: gameFields(), values: { ...g }, onSave: (vals) => saveGameFrom(vals, g) });
  },

  options(g) {
    openMenu({
      title: g.name,
      items: [
        { label: 'Играть', icon: 'play', run: () => this.launch(g) },
        { label: 'Изменить оформление и настройки', icon: 'gear', run: () => this.edit(g) },
        { label: 'Подтянуть оформление из Steam', icon: 'download', run: async () => {
          const r = g.type === 'steam' && g.appid ? await api.steamArt(g.appid) : await api.steamFind(g.name);
          if (r.ok === false) { toast(r.error, { err: true }); return; }
          if (r.hero) g.hero = r.hero;
          if (r.logo) g.logo = r.logo;
          if (r.icon && !r.hero && !g.icon) g.icon = r.icon;
          save(); checkAch(); App.refresh('g' + g.id);
          toast(r.hero || r.logo ? 'Оформление обновлено' : 'Подходящих картинок не нашлось', { err: !(r.hero || r.logo) });
        } },
        { sep: true },
        { label: 'Убрать из библиотеки', icon: 'x', danger: true, run: () => confirmBox(`Убрать «${g.name}» из библиотеки? Сама игра не удалится.`, 'Убрать', () => {
          S.games = S.games.filter((x) => x.id !== g.id);
          save(); App.refresh();
        }) },
      ],
    });
  },

  onEnded(d) {
    const g = S.games.find((x) => x.id === d.id);
    if (!g || !d.seconds) { App.dirty = true; return; }
    g.playSeconds = (g.playSeconds || 0) + d.seconds;
    if (d.seconds > (S.stats.maxSession || 0)) S.stats.maxSession = d.seconds;
    save();
    toast(`${g.name}: сессия ${fmtHours(d.seconds)}`);
    checkAch();
    App.dirty = true;
    App.refresh();
  },
};

function card(label, value) {
  return h('div', { class: 'card info' }, h('small', {}, label), h('b', {}, value));
}

// ───── Панель «Главная» ─────
const Home = {
  render() {
    const p = $('#p-home');
    p.innerHTML = '';
    const games = sortedGames();
    const last = games.find((g) => g.lastPlayed) || games[0];
    const hr = new Date().getHours();
    const greet = hr < 5 ? 'Доброй ночи' : hr < 12 ? 'Доброе утро' : hr < 18 ? 'Добрый день' : 'Добрый вечер';

    const c = trophyCounts();
    const tro = h('button', { class: 'f trophies', 'data-key': 'tro', onClick: () => Achievements.open() },
      ...['platinum', 'gold', 'silver', 'bronze'].map((k) => h('span', { class: 'tr ' + k }, h('span', { class: 'tcup ' + k }, icon('award')), c[k])));
    p.append(
      h('div', { class: 'home-top' },
        h('div', { class: 'bigclock', id: 'bigclock' }, '--:--'),
        h('div', { class: 'bigdate', id: 'bigdate' }, ''),
        h('div', { class: 'greet' }, `${greet}, ${S.settings.userName || 'Игрок'}`)),
      tro,
    );

    const row = h('div', { class: 'row homecards' });
    // Продолжить
    if (last) {
      const cont = h('button', { class: 'f card cont', 'data-key': 'cont', onClick: () => Games.launch(last) });
      if (last.hero) cont.style.backgroundImage = `linear-gradient(90deg, rgba(5,8,16,.88), rgba(5,8,16,.2)), url("${assetUrl(last.hero)}")`;
      cont.append(
        h('small', {}, last.lastPlayed ? 'Продолжить' : 'Недавно добавлено'),
        last.logo ? h('img', { class: 'clogo', src: assetUrl(last.logo), alt: last.name }) : h('b', { class: 'ctitle' }, last.name),
        h('div', { class: 'cplay' }, icon('play'), h('span', {}, 'Играть')),
      );
      cont._options = () => Games.options(last);
      row.append(cont);
    } else {
      row.append(h('button', { class: 'f card cont empty', 'data-key': 'cont', onClick: () => { App.setTab('games'); Games.add(); } },
        h('small', {}, 'Начнём'), h('b', { class: 'ctitle' }, 'Добавь свою первую игру'), h('div', { class: 'cplay' }, icon('plus'), h('span', {}, 'Добавить'))));
    }
    // Недавние
    const recent = games.filter((g) => g.lastPlayed).slice(0, 5);
    if (recent.length) {
      row.append(h('div', { class: 'card recent' }, h('small', {}, 'Недавно играл'),
        h('div', { class: 'rtiles' }, recent.map((g) => {
          const t = h('button', { class: 'f tile mini', 'data-key': 'r' + g.id, title: g.name, onClick: () => Games.launch(g) }, gameArt(g));
          t._options = () => Games.options(g);
          return t;
        }))));
    }
    // Статистика
    const t = totals();
    row.append(h('div', { class: 'card stats' }, h('small', {}, 'Статистика'),
      h('div', { class: 'srow' }, h('b', {}, fmtHours(t.secs)), h('span', {}, 'в играх')),
      h('div', { class: 'srow' }, h('b', {}, String(t.games)), h('span', {}, plural(t.games, ['игра', 'игры', 'игр']))),
      h('div', { class: 'srow' }, h('b', {}, String(t.launches)), h('span', {}, plural(t.launches, ['запуск', 'запуска', 'запусков']))),
      h('div', { class: 'srow' }, h('b', {}, String(t.streak)), h('span', {}, plural(t.streak, ['день подряд', 'дня подряд', 'дней подряд'])))));
    // Трофеи
    const got = ACH.filter((a) => S.achievements[a.id]).sort((a, b) => S.achievements[b.id] - S.achievements[a.id]);
    const next = ACH.filter((a) => !S.achievements[a.id] && a.id !== 'platinum').slice(0, 2);
    const ach = h('button', { class: 'f card ach-card', 'data-key': 'achc', onClick: () => Achievements.open() },
      h('small', {}, `Трофеи · ${got.length} из ${ACH.length}`),
      h('div', { class: 'abar' }, h('i', { style: { width: Math.round(got.length / ACH.length * 100) + '%' } })),
      ...got.slice(0, 2).map((a) => h('div', { class: 'arow got' }, h('span', { class: 'tcup ' + a.t }, icon('award')), h('span', {}, a.n))),
      ...next.slice(0, got.length ? 1 : 2).map((a) => h('div', { class: 'arow' }, h('span', { class: 'tcup locked' }, icon('award')), h('span', {}, a.d))));
    row.append(ach);
    p.append(row);
    this.tick();
  },

  tick() {
    const c = $('#bigclock');
    if (!c) return;
    const d = new Date();
    c.textContent = d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
    $('#bigdate').textContent = d.toLocaleDateString('ru-RU', { weekday: 'long', day: 'numeric', month: 'long' });
  },
};

// ───── Панель «Приложения» ─────
const Apps = {
  render() {
    const p = $('#p-apps');
    p.innerHTML = '';
    const grid = h('div', { class: 'grid apps' });
    S.apps.forEach((a) => {
      const ic = h('div', { class: 'aicon', style: { background: a.color || '#33415c' } });
      if (a.icon) ic.style.cssText += `;background:url("${assetUrl(a.icon)}") center/cover`;
      else ic.append(icon(a.glyph || 'play'));
      const t = h('button', { class: 'f apptile', 'data-key': 'a' + a.id, onClick: () => this.launch(a) }, ic, h('span', {}, a.name));
      t._options = () => this.options(a);
      grid.append(t);
    });
    grid.append(h('button', { class: 'f apptile', 'data-key': 'aadd', onClick: () => this.edit() },
      h('div', { class: 'aicon add' }, icon('plus')), h('span', {}, 'Добавить')));
    p.append(h('h2', { class: 'ptitle' }, 'Приложения'), grid);
  },

  async launch(a) {
    if (a.kind === 'media') { Media.open(); return; }
    if (a.kind === 'web') { S.stats.sites = true; save(); checkAch(); const r = await api.openWeb({ url: a.target, embedded: true }); return r; }
    const r = await api.launchApp(a);
    if (!r.ok) { toast(r.error || 'Не удалось запустить', { err: true }); UiSound.error(); }
  },

  edit(a) {
    const v = a ? { ...a } : { name: '', kind: 'exe', target: '', args: '', admin: false, icon: '', color: '#33415c' };
    openForm({
      title: a ? 'Изменить: ' + a.name : 'Новое приложение',
      values: v,
      saveLabel: a ? 'Сохранить' : 'Добавить',
      fields: [
        { key: 'name', type: 'text', label: 'Название' },
        { key: 'kind', type: 'select', label: 'Тип', options: [
          { v: 'exe', l: 'Программа (exe, ярлык)' }, { v: 'cmd', l: 'Системная команда' }, { v: 'url', l: 'Ссылка во внешней программе' }, { v: 'web', l: 'Сайт во встроенном браузере' },
        ], show: () => !a || !['media'].includes(a.kind) },
        { key: 'target', type: 'file', label: 'Файл программы', pick: 'exe', show: (x) => x.kind === 'exe', after: async (x, pth) => {
          if (/\.lnk$/i.test(pth)) { const r = await api.resolveShortcut(pth); if (r && r.target) { x.target = r.target; x.args = r.args || ''; } }
          if (!x.name) x.name = cleanName(stripExt(baseName(pth)));
          if (!x.icon) x.icon = (await api.fileIcon(x.target)) || '';
        } },
        { key: 'target', type: 'text', label: 'Команда или адрес', placeholder: 'explorer.exe / https://…', show: (x) => ['cmd', 'url', 'web'].includes(x.kind) },
        { key: 'args', type: 'text', label: 'Параметры', show: (x) => ['exe', 'cmd'].includes(x.kind) },
        { key: 'icon', type: 'image', label: 'Иконка' },
      ],
      onSave: (x) => {
        if (!(x.name || '').trim()) { toast('Укажи название', { err: true }); return false; }
        if (x.kind !== 'media' && !(x.target || '').trim()) { toast('Укажи, что запускать', { err: true }); return false; }
        const rec = a || { id: 'a' + Date.now().toString(36), glyph: 'play' };
        Object.assign(rec, { name: x.name.trim(), kind: x.kind, target: x.target || '', args: x.args || '', icon: x.icon || '' });
        if (!a) S.apps.push(rec);
        save(); App.refresh('a' + rec.id);
        return true;
      },
    });
  },

  options(a) {
    openMenu({ title: a.name, items: [
      { label: 'Открыть', icon: 'play', run: () => this.launch(a) },
      { label: 'Изменить', icon: 'gear', run: () => this.edit(a) },
      { sep: true },
      { label: 'Убрать', icon: 'x', danger: true, run: () => { S.apps = S.apps.filter((x) => x.id !== a.id); save(); App.refresh(); } },
    ] });
  },
};

// ───── Панель «Сайты» ─────
const Sites = {
  render() {
    const p = $('#p-sites');
    p.innerHTML = '';
    const grid = h('div', { class: 'grid sites' });
    S.sites.forEach((s) => {
      let host = '';
      try { host = new URL(/^https?:/i.test(s.url) ? s.url : 'https://' + s.url).hostname.replace(/^www\./, ''); } catch { host = s.url; }
      const fav = s.icon ? assetUrl(s.icon) : `https://www.google.com/s2/favicons?domain=${encodeURIComponent(host)}&sz=128`;
      const t = h('button', { class: 'f sitetile', 'data-key': 's' + s.id, style: { '--c': s.color || '#33415c' }, onClick: () => this.open(s) },
        h('img', { class: 'fav', src: fav, alt: '', onError: (e) => { e.target.style.display = 'none'; } }),
        h('b', {}, s.name), h('small', {}, host));
      t._options = () => this.options(s);
      grid.append(t);
    });
    grid.append(h('button', { class: 'f sitetile addsite', 'data-key': 'sadd', onClick: () => this.edit() }, icon('plus'), h('b', {}, 'Добавить сайт')));
    p.append(h('h2', { class: 'ptitle' }, 'Сайты'), grid);
  },

  async open(s) {
    S.stats.sites = true;
    save();
    checkAch();
    await api.openWeb({ url: s.url, embedded: s.embedded !== false });
  },

  edit(s) {
    const v = s ? { ...s } : { name: '', url: '', embedded: true, icon: '', color: '#33415c' };
    openForm({
      title: s ? 'Изменить: ' + s.name : 'Новый сайт',
      values: v,
      saveLabel: s ? 'Сохранить' : 'Добавить',
      fields: [
        { key: 'name', type: 'text', label: 'Название' },
        { key: 'url', type: 'text', label: 'Адрес', placeholder: 'youtube.com' },
        { key: 'embedded', type: 'toggle', label: 'Открывать во встроенном браузере', hint: 'выключено — откроется в браузере Windows' },
        { key: 'icon', type: 'image', label: 'Иконка (необязательно)' },
      ],
      onSave: (x) => {
        if (!(x.name || '').trim() || !(x.url || '').trim()) { toast('Заполни название и адрес', { err: true }); return false; }
        const rec = s || { id: 's' + Date.now().toString(36), color: '#' + (hashStr(x.name) % 0xffffff).toString(16).padStart(6, '3').slice(0, 6) };
        if (!s) { const hue = hashStr(x.name) % 360; rec.color = `hsl(${hue},45%,34%)`; }
        Object.assign(rec, { name: x.name.trim(), url: x.url.trim(), embedded: !!x.embedded, icon: x.icon || '' });
        if (!s) S.sites.push(rec);
        save(); App.refresh('s' + rec.id);
        return true;
      },
    });
  },

  options(s) {
    openMenu({ title: s.name, items: [
      { label: 'Открыть', icon: 'globe', run: () => this.open(s) },
      { label: 'Изменить', icon: 'gear', run: () => this.edit(s) },
      { sep: true },
      { label: 'Убрать', icon: 'x', danger: true, run: () => { S.sites = S.sites.filter((x) => x.id !== s.id); save(); App.refresh(); } },
    ] });
  },
};

// ───── Импорт из Steam ─────
const SteamImport = {
  async open() {
    toast('Ищу установленные игры Steam…');
    const r = await api.steamScan();
    const have = new Set(S.games.filter((g) => g.type === 'steam').map((g) => String(g.appid)));
    const list = r.games.filter((x) => !have.has(x.appid));
    if (!r.found) { toast('Steam не найден на этом компьютере', { err: true }); return; }
    if (!list.length) { toast(r.games.length ? 'Все установленные игры Steam уже в библиотеке' : 'Установленных игр Steam не найдено'); return; }
    const chosen = new Set(list.map((x) => x.appid));
    const body = h('div', { class: 'implist' });
    const rows = list.map((x) => {
      const b = h('button', { class: 'f toggle-row on', onClick: () => {
        if (chosen.has(x.appid)) chosen.delete(x.appid); else chosen.add(x.appid);
        b.classList.toggle('on', chosen.has(x.appid));
        counter.textContent = `Выбрано: ${chosen.size}`;
      } }, h('i', {}), h('span', {}, x.name), h('small', {}, x.appid));
      body.append(b);
      return b;
    });
    const counter = h('div', { class: 'impcount' }, `Выбрано: ${chosen.size}`);
    modal({
      title: `Игры Steam на этом компьютере (${list.length})`,
      body: h('div', {}, counter, body),
      wide: true,
      buttons: [
        { label: 'Отмена', onClick: (m) => m.close() },
        { label: 'Снять всё / выбрать всё', onClick: () => {
          const all = chosen.size < list.length;
          chosen.clear();
          if (all) list.forEach((x) => chosen.add(x.appid));
          rows.forEach((b, i) => b.classList.toggle('on', chosen.has(list[i].appid)));
          counter.textContent = `Выбрано: ${chosen.size}`;
        } },
        { label: 'Импортировать', primary: true, onClick: (m) => { m.close(); this.run(list.filter((x) => chosen.has(x.appid))); } },
      ],
    });
  },

  async run(items) {
    if (!items.length) return;
    const added = items.map((x) => {
      const g = { id: 'g' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), added: Date.now(), playSeconds: 0, launches: 0, lastPlayed: 0,
        name: x.name, type: 'steam', path: '', args: '', cwd: '', admin: false, process: '', appid: x.appid, icon: '', hero: '', logo: '', music: '', musicName: '' };
      S.games.push(g);
      return g;
    });
    save(); checkAch(); App.refresh();
    toast(`Добавлено игр: ${added.length}. Загружаю оформление…`);
    let n = 0;
    for (const g of added) {
      await fetchSteamArtFor(g);
      n++;
    }
    toast(`Оформление загружено для ${n} ${plural(n, ['игры', 'игр', 'игр'])}`);
  },
};

// ───── Мультимедиа ─────
const Media = {
  list: [], idx: -1, el: null, v: null,

  open() {
    Music.set('');
    const el = h('div', { class: 'layer media' });
    this.el = el;
    const folders = h('div', { class: 'mfolders' },
      ...[['videos', 'Видео'], ['music', 'Музыка'], ['downloads', 'Загрузки']].map(([k, l]) => h('button', { class: 'f btn', onClick: () => this.load(INFO.folders[k]) }, l)),
      h('button', { class: 'f btn', onClick: async () => { const p = await api.pick('folder'); if (p) this.load(p); } }, 'Другая папка…'));
    this.listEl = h('div', { class: 'mlist' });
    this.title = h('div', { class: 'mtitle' }, 'Выбери папку с видео или музыкой');
    this.v = h('video', { class: 'mvideo', preload: 'auto' });
    this.bar = h('i', {});
    this.v.addEventListener('timeupdate', () => { this.bar.style.width = (this.v.duration ? this.v.currentTime / this.v.duration * 100 : 0) + '%'; });
    this.v.addEventListener('ended', () => this.step(1));
    this.v.addEventListener('error', () => { if (this.idx >= 0) toast('Не удалось воспроизвести файл (формат не поддерживается)', { err: true }); });
    const ctl = h('div', { class: 'mctl' },
      h('button', { class: 'f btn round', onClick: () => this.step(-1) }, '⏮'),
      h('button', { class: 'f btn round', onClick: () => { this.v.currentTime = Math.max(0, this.v.currentTime - 10); } }, '−10'),
      h('button', { class: 'f btn round big', id: 'mplay', onClick: () => { if (this.v.paused) this.v.play(); else this.v.pause(); } }, '⏯'),
      h('button', { class: 'f btn round', onClick: () => { this.v.currentTime += 10; } }, '+10'),
      h('button', { class: 'f btn round', onClick: () => this.step(1) }, '⏭'),
      h('button', { class: 'f btn round', onClick: () => { this.v.volume = Math.max(0, this.v.volume - 0.1); } }, '🔉'),
      h('button', { class: 'f btn round', onClick: () => { this.v.volume = Math.min(1, this.v.volume + 0.1); } }, '🔊'),
      h('button', { class: 'f btn', onClick: () => this.close() }, 'Закрыть'));
    el.append(h('div', { class: 'mwrap' },
      h('div', { class: 'mleft' }, folders, this.listEl),
      h('div', { class: 'mright' }, this.v, this.title, h('div', { class: 'mbar' }, this.bar), ctl)));
    Nav.openLayer(el, { onBack: () => this.close() });
    if (S.settings.mediaFolder) this.load(S.settings.mediaFolder);
  },

  async load(dir) {
    if (!dir) return;
    S.settings.mediaFolder = dir;
    save();
    this.list = await api.mediaScan(dir);
    this.listEl.innerHTML = '';
    if (!this.list.length) { this.listEl.append(h('div', { class: 'mempty' }, 'В этой папке нет видео и музыки')); return; }
    this.list.forEach((m, i) => this.listEl.append(h('button', { class: 'f mitem', 'data-i': i, onClick: () => this.play(i) }, h('span', {}, m.video ? '▶' : '♪'), m.name)));
    const first = $('.mitem', this.listEl);
    if (first) first.focus({ preventScroll: true });
  },

  play(i) {
    const m = this.list[i];
    if (!m) return;
    this.idx = i;
    this.v.src = m.url;
    this.v.classList.toggle('audio', !m.video);
    this.title.textContent = m.name;
    this.v.play().catch(() => {});
    $$('.mitem', this.listEl).forEach((b, k) => b.classList.toggle('now', k === i));
  },

  step(d) {
    if (!this.list.length) return;
    this.play((this.idx + d + this.list.length) % this.list.length);
  },

  close() {
    if (!this.el) return;
    try { this.v.pause(); this.v.removeAttribute('src'); this.v.load(); } catch { /* ignore */ }
    const el = this.el;
    this.el = null;
    Nav.closeLayer(el);
    App.updateMusic();
  },
};

// ───── Настройки ─────
const Settings = {
  open() {
    const s = S.settings;
    openForm({
      title: 'Настройки',
      values: { ...s },
      fields: [
        { key: 'userName', type: 'text', label: 'Твоё имя', hint: 'показывается на главной' },
        { key: 'autostart', type: 'toggle', label: 'Запускать вместе с Windows' },
        { key: 'fullscreen', type: 'toggle', label: 'Полноэкранный режим' },
        { key: 'uiSounds', type: 'toggle', label: 'Звуки интерфейса' },
        { key: 'music', type: 'toggle', label: 'Фоновая музыка' },
        { key: 'volume', type: 'stepper', label: 'Громкость музыки', min: 0, max: 100, step: 10, unit: '%' },
        { key: 'musicHome', type: 'audio', label: 'Музыка: Главная' },
        { key: 'musicGames', type: 'audio', label: 'Музыка: Игры (по умолчанию)', hint: 'если у игры нет своей музыки' },
        { key: 'musicApps', type: 'audio', label: 'Музыка: Приложения' },
        { key: 'musicSites', type: 'audio', label: 'Музыка: Сайты' },
        { key: 'bgHome', type: 'image', label: 'Фон главной, приложений и сайтов' },
        { key: 'dir', type: 'button', label: 'Открыть папку с данными (резервная копия)', run: () => api.openDataDir() },
      ],
      onSave: async (v) => {
        const keys = ['userName', 'autostart', 'fullscreen', 'uiSounds', 'music', 'volume', 'musicHome', 'musicHomeName', 'musicGames', 'musicGamesName', 'musicApps', 'musicAppsName', 'musicSites', 'musicSitesName', 'bgHome'];
        const prevFs = s.fullscreen, prevAuto = s.autostart;
        keys.forEach((k) => { if (v[k] !== undefined) s[k] = v[k]; });
        save();
        applySettings();
        if (prevFs !== s.fullscreen) api.setFullscreen(s.fullscreen);
        if (prevAuto !== s.autostart) api.setAutostart(s.autostart);
        App.refresh();
        return true;
      },
    });
  },
};

function applySettings() {
  const s = S.settings;
  UiSound.on = !!s.uiSounds;
  Music.vol = Math.max(0, Math.min(1, (s.volume == null ? 60 : s.volume) / 100));
  Music.setVolume(Music.vol);
  if (Music.enabled !== !!s.music) Music.setEnabled(!!s.music);
  App.updateMusic();
  App.updateBg();
}

// ───── Общий доступ к панелям ─────
const Panels = {
  render(tab) { ({ home: Home, games: Games, apps: Apps, sites: Sites })[tab].render(); },
  defaultFocus() {
    const tab = App.tab;
    const p = $('#p-' + tab);
    const key = App.focusKey[tab];
    let t = key && $(`[data-key="${key}"]`, p);
    if (!t && tab === 'games') t = Games.currentTile();
    if (!t) t = $('.f', p);
    return t;
  },
};
